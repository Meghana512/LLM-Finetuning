-- Runtime search functions for the V11/V13 document embedding table.
--
-- This project now uses public.brsr_document_embeddings for document RAG.
-- The RPC names are intentionally kept as match_document_chunks and
-- search_document_chunks_keyword so the FastAPI backend does not need a
-- separate deployment contract.
--
-- Active embedding source:
--   public.brsr_document_embeddings view -> public.brsr_embeddings + public.brsr_embeddings_v2
--
-- If the tables are non-overlapping shards, UNION ALL is correct and fastest.
-- If the same chunk IDs exist in both tables, deduplicate before ingestion or
-- change this view to use DISTINCT ON (id).
-- Expected embedding dimension in the loaded tables: 1024

create extension if not exists vector;

create or replace view public.brsr_document_embeddings as
select *
from public.brsr_embeddings
union all
select *
from public.brsr_embeddings_v2;

drop function if exists public.match_document_chunks(vector(1536), integer, uuid, text, text, text);
drop function if exists public.match_document_chunks(vector(1536), integer, text, text, text, text);
drop function if exists public.match_document_chunks(vector(1024), integer, uuid, text, text, text);
drop function if exists public.match_document_chunks(vector(1024), integer, text, text, text, text);

create or replace function public.match_document_chunks(
    query_embedding vector(1024),
    match_count integer,
    filter_workspace_id text,
    filter_company text default null,
    filter_reporting_year text default null,
    filter_corpus_type text default null
)
returns table (
    id text,
    document_id text,
    workspace_id text,
    parent_chunk_id text,
    corpus_type text,
    company text,
    sector text,
    reporting_year text,
    report_type text,
    section_title text,
    page_number integer,
    chunk_index integer,
    chunk_level text,
    chunk_text text,
    chunk_type text,
    intent_label text,
    similarity double precision
)
language sql stable
as $$
    select
        coalesce(dc.id::text, dc.chunk_id::text, dc.child_id::text) as id,
        dc.document_id::text as document_id,
        dc.workspace_id::text as workspace_id,
        coalesce(dc.parent_chunk_id::text, dc.parent_id::text) as parent_chunk_id,
        dc.corpus_type,
        coalesce(dc.company, dc.company_name) as company,
        dc.sector,
        dc.reporting_year,
        dc.report_type,
        coalesce(dc.section_title, dc.section_path) as section_title,
        coalesce(dc.page_number, dc.page_start) as page_number,
        coalesce(dc.chunk_index, dc.child_index) as chunk_index,
        coalesce(dc.chunk_level, dc.chunk_type) as chunk_level,
        coalesce(dc.chunk_text, dc.embedding_text, dc.text) as chunk_text,
        dc.chunk_type,
        coalesce(dc.intent_label, dc.topic_key) as intent_label,
        1 - (dc.embedding <=> query_embedding) as similarity
    from public.brsr_document_embeddings dc
    where (filter_workspace_id is null or dc.workspace_id is null or dc.workspace_id::text = filter_workspace_id)
      and dc.embedding is not null
      and (
          filter_company is null
          or lower(coalesce(dc.company, dc.company_name, '')) = lower(filter_company)
          or lower(coalesce(dc.company, dc.company_name, '')) like '%' || lower(filter_company) || '%'
          or regexp_replace(lower(coalesce(dc.company, dc.company_name, '')), '\m(limited|ltd|private|pvt|public|plc|inc|corp|corporation|company|co)\M\.?', '', 'g')
             like '%' || regexp_replace(lower(filter_company), '\m(limited|ltd|private|pvt|public|plc|inc|corp|corporation|company|co)\M\.?', '', 'g') || '%'
      )
      and (filter_reporting_year is null or dc.reporting_year = filter_reporting_year)
      and (filter_corpus_type is null or dc.corpus_type = filter_corpus_type)
    order by dc.embedding <=> query_embedding
    limit greatest(1, least(match_count, 100));
$$;

drop function if exists public.search_document_chunks_keyword(text, integer, uuid, text, text, text);
drop function if exists public.search_document_chunks_keyword(text, integer, text, text, text, text);

create or replace function public.search_document_chunks_keyword(
    search_query text,
    match_count integer,
    filter_workspace_id text,
    filter_company text default null,
    filter_reporting_year text default null,
    filter_corpus_type text default null
)
returns table (
    id text,
    document_id text,
    workspace_id text,
    parent_chunk_id text,
    corpus_type text,
    company text,
    sector text,
    reporting_year text,
    report_type text,
    section_title text,
    page_number integer,
    chunk_index integer,
    chunk_level text,
    chunk_text text,
    chunk_type text,
    intent_label text,
    text_rank real
)
language sql stable
as $$
    with query as (
        select websearch_to_tsquery('english', search_query) as value
    )
    select
        coalesce(dc.id::text, dc.chunk_id::text, dc.child_id::text) as id,
        dc.document_id::text as document_id,
        dc.workspace_id::text as workspace_id,
        coalesce(dc.parent_chunk_id::text, dc.parent_id::text) as parent_chunk_id,
        dc.corpus_type,
        coalesce(dc.company, dc.company_name) as company,
        dc.sector,
        dc.reporting_year,
        dc.report_type,
        coalesce(dc.section_title, dc.section_path) as section_title,
        coalesce(dc.page_number, dc.page_start) as page_number,
        coalesce(dc.chunk_index, dc.child_index) as chunk_index,
        coalesce(dc.chunk_level, dc.chunk_type) as chunk_level,
        coalesce(dc.chunk_text, dc.embedding_text, dc.text) as chunk_text,
        dc.chunk_type,
        coalesce(dc.intent_label, dc.topic_key) as intent_label,
        ts_rank_cd(
            to_tsvector('english', coalesce(dc.search_text, dc.chunk_text, dc.embedding_text, dc.text, '')),
            query.value
        ) as text_rank
    from public.brsr_document_embeddings dc
    cross join query
    where (filter_workspace_id is null or dc.workspace_id is null or dc.workspace_id::text = filter_workspace_id)
      and to_tsvector('english', coalesce(dc.search_text, dc.chunk_text, dc.embedding_text, dc.text, '')) @@ query.value
      and (
          filter_company is null
          or lower(coalesce(dc.company, dc.company_name, '')) = lower(filter_company)
          or lower(coalesce(dc.company, dc.company_name, '')) like '%' || lower(filter_company) || '%'
          or regexp_replace(lower(coalesce(dc.company, dc.company_name, '')), '\m(limited|ltd|private|pvt|public|plc|inc|corp|corporation|company|co)\M\.?', '', 'g')
             like '%' || regexp_replace(lower(filter_company), '\m(limited|ltd|private|pvt|public|plc|inc|corp|corporation|company|co)\M\.?', '', 'g') || '%'
      )
      and (filter_reporting_year is null or dc.reporting_year = filter_reporting_year)
      and (filter_corpus_type is null or dc.corpus_type = filter_corpus_type)
    order by text_rank desc, coalesce(dc.id::text, dc.chunk_id::text, dc.child_id::text)
    limit greatest(1, least(match_count, 100));
$$;

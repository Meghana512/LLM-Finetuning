-- Optional performance indexes for document retrieval.
--
-- Run the main document_retrieval.sql first. Only run this file after basic
-- retrieval works.
--
-- These indexes can take a long time on large embedding tables. If Supabase SQL
-- Editor times out, run one statement at a time, run during off-hours, or run
-- from a direct database connection with a longer statement_timeout.

create extension if not exists vector;

create index if not exists brsr_embeddings_embedding_hnsw_idx
on public.brsr_embeddings using hnsw (embedding vector_cosine_ops);

create index if not exists brsr_embeddings_search_text_gin_idx
on public.brsr_embeddings using gin (
    to_tsvector('english', coalesce(search_text, chunk_text, embedding_text, text, ''))
);

create index if not exists brsr_embeddings_v2_embedding_hnsw_idx
on public.brsr_embeddings_v2 using hnsw (embedding vector_cosine_ops);

create index if not exists brsr_embeddings_v2_search_text_gin_idx
on public.brsr_embeddings_v2 using gin (
    to_tsvector('english', coalesce(search_text, chunk_text, embedding_text, text, ''))
);

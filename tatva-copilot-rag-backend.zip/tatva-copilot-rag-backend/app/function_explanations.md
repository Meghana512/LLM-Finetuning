# ESG Copilot Backend Function and Tool Explanations

This document provides a comprehensive explanation of all functions, tools, endpoints, and classes defined across three core modules of the backend codebase:
1. [mcp_server.py](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/mcp_server.py) (FastMCP server and tool registrations)
2. [llm.py](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/llm.py) (LLM response synthesis and tool call handling)
3. [main.py](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/main.py) (FastAPI application and route definitions)

---

## 1. mcp_server.py

The [mcp_server.py](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/mcp_server.py) file initializes a FastMCP server named `"Tatva ESG Copilot"` and exposes six MCP tools. These tools are designed to fetch structured KPI data, query unstructured ESG documents/policies, retrieve regulations, look up benchmarks, perform gap analysis, and generate draft disclosure contexts.

### search_esg_kpis
* **Definition Location**: [search_esg_kpis](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/mcp_server.py#L17)
* **Signature**:
  ```python
  def search_esg_kpis(
      company_names: list[str], 
      query: str, 
      reporting_year: str = None
  ) -> dict
  ```
* **Purpose**: Retrieves verified numerical ESG KPI metrics (e.g. GHG emissions, gender diversity ratios, water consumption) and their Year-over-Year (YoY) changes. It supports looking up a single company or multiple companies for comparison.
* **Arguments**:
  - `company_names`: A list of target companies (e.g. `["Siemens Limited"]`).
  - `query`: A natural language query about the target metrics (e.g. `"Scope 1 emissions"`).
  - `reporting_year`: Optional reporting year filter (e.g. `"FY 2022-23"`).
* **Internal Behavior**:
  - Cleans input lists to eliminate empty/falsy strings.
  - **Single Company Path**: If only one company is requested, it delegates to `retrieve_kpis` and formats the answer using `format_kpi_answer`.
  - **Multi-Company Path**: If more than one company is requested, it calls `retrieve_kpis_for_companies` and formats the answer using `format_comparison_answer`.
  - **Returns**: A dictionary containing:
    - `"answer"`: The formatted markdown text answer.
    - `"kpi_facts"`: An array of structured factual items.
    - `"citations"`: List of citations pointing back to source tables.
    - `"confidence"`: A string indicating retrieval confidence (`"high"`, `"medium"`, or `"low"`).
    - `"warnings"`: Any warnings generated during retrieval.

### search_esg_documents
* **Definition Location**: [search_esg_documents](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/mcp_server.py#L78)
* **Signature**:
  ```python
  def search_esg_documents(
      query: str, 
      company_name: str = None, 
      reporting_year: str = None,
      peer_companies: list[str] = None
  ) -> dict
  ```
* **Purpose**: Searches unstructured ESG document sections (such as policy descriptions, environmental strategies, or explanation narratives) in corporate reports. Use this tool when queries ask "why", "how", or request detailed policy descriptions.
* **Arguments**:
  - `query`: Textual search query.
  - `company_name`: The primary company name.
  - `reporting_year`: Optional reporting year filter.
  - `peer_companies`: Optional list of peer company names to search in parallel.
* **Internal Behavior**:
  - Combines `company_name` and `peer_companies` into a single de-duplicated list.
  - If the combined list is empty, performs a global document chunk search (`retrieve_document_chunks` with `company=None`) and returns a formatted result.
  - If companies are specified, iterates through each company and performs document chunk retrieval. It translates and maps citation source IDs (e.g. from standard IDs to unique mapped IDs like `S1`, `S2` to avoid citation conflicts in multi-company queries) and compiles a joined markdown explanation.
  - **Returns**: A dictionary containing `"answer"` (concatenated markdown narratives), `"citations"`, `"retrieved_chunks"`, `"confidence"`, and `"warnings"`.

### retrieve_regulations
* **Definition Location**: [retrieve_regulations](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/mcp_server.py#L177)
* **Signature**:
  ```python
  def retrieve_regulations(
      query: str,
      framework: str = "BRSR"
  ) -> dict
  ```
* **Purpose**: Retrieves official ESG regulatory guidance, requirements, rules, and principles (e.g. SEBI's BRSR guidance notes, GRI frameworks).
* **Arguments**:
  - `query`: The regulatory framework topic or question.
  - `framework`: The target ESG framework string (defaults to `"BRSR"`).
* **Internal Behavior**:
  - Calls `retrieve_document_chunks` with `company=None` and `corpus_type="regulatory"`.
  - Formats the retrieved chunks using `format_document_answer`.
  - **Returns**: A dictionary with `"answer"`, `"citations"`, `"retrieved_chunks"`, `"confidence"`, and `"warnings"`.

### retrieve_benchmarks
* **Definition Location**: [retrieve_benchmarks](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/mcp_server.py#L204)
* **Signature**:
  ```python
  def retrieve_benchmarks(
      query: str,
      peer_companies: list[str] = None
  ) -> dict
  ```
* **Purpose**: Fetches industry best practices, peer ESG benchmarks, and corporate disclosure examples on specific ESG issues.
* **Arguments**:
  - `query`: The ESG topic to benchmark (e.g., `"carbon neutrality targets"`).
  - `peer_companies`: Optional list of peer company names.
* **Internal Behavior**:
  - If no peer companies are provided, it performs a global search prefixed with `"best practice benchmark "` using `company=None`.
  - If peer companies are provided, it loops through each peer, fetches the corresponding document chunks, remaps source IDs to `B1`, `B2`, etc., to avoid overlapping citation keys, and outputs a formatted benchmark list.
  - **Returns**: A dictionary containing `"answer"` (joined benchmarks), `"citations"`, `"retrieved_chunks"`, `"confidence"`, and `"warnings"`.

### analyze_gaps
* **Definition Location**: [analyze_gaps](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/mcp_server.py#L282)
* **Signature**:
  ```python
  def analyze_gaps(
      primary_company: str,
      peer_companies: list[str],
      topic: str
  ) -> dict
  ```
* **Purpose**: Directly compares the disclosure narrative of a primary target company against its peers on a specific topic to assist in identifying reporting gaps.
* **Arguments**:
  - `primary_company`: The name of the company to analyze.
  - `peer_companies`: A list of peer company names to compare against.
  - `topic`: The specific ESG metric or topic.
* **Internal Behavior**:
  - Queries document chunks and formats an answer for the primary company.
  - Loops through each peer company, retrieving document chunks and formatting answers.
  - Combines these answers side-by-side into a comparison string block (`comparison_data`), and merges all citations, chunks, and warnings.
  - **Returns**: A dictionary containing `"comparison_data"`, `"citations"`, `"retrieved_chunks"`, and `"warnings"`.

### draft_disclosure
* **Definition Location**: [draft_disclosure](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/mcp_server.py#L329)
* **Signature**:
  ```python
  def draft_disclosure(
      company_name: str,
      topic: str,
      retrieved_context: str,
      kpis: dict = None
  ) -> dict
  ```
* **Purpose**: Generates context for draft disclosures (e.g. narratives on governance, climate risks, or oversight policies) matching framework standards.
* **Arguments**:
  - `company_name`: The company name.
  - `topic`: The specific narrative section/topic to draft.
  - `retrieved_context`: Official guidelines, rules, or peer template text.
  - `kpis`: An optional dictionary of metrics/values to cite or weave into the draft.
* **Internal Behavior**:
  - Serializes `kpis` into a list of bullet points if provided.
  - Combines the company name, topic, KPIs, and regulatory/peer context into a structured string block.
  - **Returns**: A dictionary containing a single key `"draft_prompt_context"`.

---

## 2. llm.py

The [llm.py](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/llm.py) file coordinates LLM response generation. It exposes a helper validation function and the main orchestration loop that allows a Llama model to dynamically select and invoke the MCP tools defined in [mcp_server.py](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/mcp_server.py).

### is_regulatory_query
* **Definition Location**: [is_regulatory_query](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/llm.py#L15)
* **Signature**:
  ```python
  def is_regulatory_query(message: str) -> bool
  ```
* **Purpose**: Utility function that determines if the user query is asking about a regulatory requirement or reporting framework.
* **Arguments**:
  - `message`: The user's prompt text.
* **Internal Behavior**:
  - Executes a case-insensitive regular expression match `REGULATORY_PATTERN` seeking keywords like `brsr`, `ifrs s1`, `gri`, `sasb`, `csrd`, `sebi`, `framework`, etc. Returns `True` if a match is found.

### generate_llm_answer
* **Definition Location**: [generate_llm_answer](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/llm.py#L18)
* **Signature**:
  ```python
  def generate_llm_answer(
      query: str,
      *,
      company_name: str | None = None,
      reporting_year: str | None = None,
      peer_companies: list[str] = None,
      fallback_answer: str = ""
  ) -> dict[str, Any]
  ```
* **Purpose**: Synthesizes a structured answer using the Groq Llama 3.1 8B API with dynamic tool utilization.
* **Arguments**:
  - `query`: User's prompt.
  - `company_name` (keyword-only): Fallback/sidebar company name.
  - `reporting_year` (keyword-only): Fallback/sidebar reporting year.
  - `peer_companies` (keyword-only): List of fallback/sidebar peer companies.
  - `fallback_answer` (keyword-only): Fallback text if the LLM cannot be run.
* **Internal Behavior**:
  - **API/Package Verification**: Verifies `GROQ_API_KEY` is in the environment and checks if the `groq` package is installed; fails back gracefully to direct retrieval answers if missing.
  - **Tool Schemas**: Translates the six MCP tools into standard JSON tool schemas expected by OpenAI-style tool-calling interfaces.
  - **System Prompt**: Defines rules for the model. Crucially, it directs the LLM to extract company names directly from the query if present, bypassing the sidebar default values.
  - **Tool-Call Execution Loop**:
    - Operates for up to 3 turns.
    - Sends the messages, tool schemas, and prompt inputs to Groq.
    - If the LLM generates a tool call, the local Python function corresponding to that tool name is imported from `app.mcp_server` and executed with the parsed arguments.
    - The output of the tool is added to the chat history under the role `tool`.
    - Accumulates confidence, citations, facts, and chunks from tool responses.
    - Once the LLM ceases tool calls, the final text response is synthesized.
  - **Deduplication**: Deduplicates the accumulated citations, facts, and retrieved document chunks.
  - **Intent Classification**: Classifies the query's intent into one of:
    - `"peer_benchmarking"` (if `analyze_gaps` is called or a multi-company KPI search is performed).
    - `"disclosure_generation"` (if `draft_disclosure` is called).
    - `"regulatory_qa"` (if regulatory tools are called and matches a regulatory query pattern).
    - `"company_qa"` (default fallback).
  - **Returns**: A unified dictionary payload with `"intent"`, `"answer"`, `"kpi_facts"`, `"citations"`, `"retrieved_chunks"`, `"confidence"`, `"warnings"`, and `"tools_called"`.

---

## 3. main.py

The [main.py](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/main.py) file builds the FastAPI application instance. It mounts the FastMCP server, defines the request payload schemas, and sets up endpoints for health checking, serving the UI frontend, and initiating user chats.

### ChatRequest
* **Definition Location**: [ChatRequest](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/main.py#L13)
* **Type**: `pydantic.BaseModel`
* **Purpose**: Input schema validation for the `/chat` POST endpoint.
* **Fields**:
  - `company_name`: `str` (the targeted company).
  - `message`: `str` (the chat message query).
  - `reporting_year`: `str | None` (optional reporting year).
  - `peer_companies`: `list[str]` (list of comparison companies).

### health
* **Definition Location**: [health](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/main.py#L20)
* **Path**: `GET /health`
* **Purpose**: A basic liveness probe check.
* **Returns**: `{"status": "ok"}`

### get_ui
* **Definition Location**: [get_ui](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/main.py#L25)
* **Path**: `GET /`
* **Purpose**: Serves the primary static HTML client interface file (`index.html`) if it exists on the system.
* **Returns**: HTML string content from `app/static/index.html` or a fallback file-not-found error message.

### chat
* **Definition Location**: [chat](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/main.py#L34)
* **Path**: `POST /chat`
* **Purpose**: Core entry endpoint for submitting queries.
* **Arguments**:
  - `req`: A validated `ChatRequest` instance.
* **Internal Behavior**:
  - Triggers `generate_llm_answer` using the request parameters.
  - Combines and deduplicates companies from the results' citations and kpi facts to build the list of companies actually referenced in the response. If none are found, falls back to the requested primary company name.
  - Evaluates which backend retrieval paths were activated (`kpi`, `document_rag`, or `mcp_tool_use`) to allow the UI to display the exact retrieval journey.
  - **Returns**: A formatted JSON response compatible with the frontend dashboard widgets, containing the intent, answer, kpi facts, citations, confidence rating, affected companies, requested companies, retrieval paths used, warnings, and retrieved document chunks.

# pyrefly: ignore [missing-import]
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
import os
from app.llm import generate_llm_answer, generate_esg_report
from app.mcp_server import mcp

app = FastAPI(title="tatva.copilot RAG Backend")

# Mount the MCP server's HTTP/SSE app under /mcp
app.mount("/mcp", mcp.sse_app())

class ChatRequest(BaseModel):
    company_name: str
    message: str
    reporting_year: str | None = None
    peer_companies: list[str] = Field(default_factory=list)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/", response_class=HTMLResponse)
def get_ui():
    ui_path = os.path.join(os.path.dirname(__file__), "static", "index.html")
    if os.path.exists(ui_path):
        with open(ui_path, "r", encoding="utf-8") as f:
            return f.read()
    return "UI static file not found."


@app.post("/chat")
def chat(req: ChatRequest):
    result = generate_llm_answer(
        query=req.message,
        company_name=req.company_name,
        reporting_year=req.reporting_year,
        peer_companies=req.peer_companies,
    )

    # Format result to be compatible with UI dashboard
    companies = sorted(list(set(
        [c.get("company") for c in result["citations"] if c.get("company")] +
        [f.get("company_name") for f in result["kpi_facts"] if f.get("company_name")]
    )))

    # If no companies were matched in citations/kpi_facts, fallback to requested company
    if not companies:
        companies = [req.company_name] if req.company_name else []

    paths = []
    if result["kpi_facts"]:
        paths.append("kpi")
    if result["retrieved_chunks"]:
        paths.append("document_rag")
    if not paths:
        paths.append("mcp_tool_use")

    return {
        "intent": result["intent"],
        "answer": result["answer"],
        "kpi_facts": result["kpi_facts"],
        "citations": result["citations"],
        "confidence": result["confidence"],
        "companies": companies,
        "requested_companies": [req.company_name] + req.peer_companies,
        "retrieval_paths_used": paths,
        "warnings": result["warnings"],
        "retrieved_chunks": result["retrieved_chunks"]
    }


class ReportRequest(BaseModel):
    company_name: str
    reporting_year: str | None = None
    peer_companies: list[str] = Field(default_factory=list)


@app.post("/chat/report")
def chat_report(req: ReportRequest):
    result = generate_esg_report(
        company_name=req.company_name,
        reporting_year=req.reporting_year,
        peer_companies=req.peer_companies,
    )

    # Format result to be compatible with UI dashboard
    companies = sorted(list(set(
        [c.get("company") for c in result["citations"] if c.get("company")] +
        [f.get("company_name") for f in result["kpi_facts"] if f.get("company_name")]
    )))

    if not companies:
        companies = [req.company_name] if req.company_name else []

    paths = ["kpi", "document_rag"]

    return {
        "intent": result["intent"],
        "answer": result["answer"],
        "kpi_facts": result["kpi_facts"],
        "citations": result["citations"],
        "confidence": result["confidence"],
        "companies": companies,
        "requested_companies": [req.company_name] + req.peer_companies,
        "retrieval_paths_used": paths,
        "warnings": result["warnings"],
        "retrieved_chunks": result["retrieved_chunks"]
    }


@app.get("/chat/companies")
def get_companies():
    from app.kpi_retriever import get_supabase_client, WORKSPACE_ID
    client = get_supabase_client()
    companies = []
    start = 0
    limit = 1000
    while True:
        data = (
            client.table("companies")
            .select("company_name, nse_symbol")
            .eq("workspace_id", WORKSPACE_ID)
            .range(start, start + limit - 1)
            .execute()
        ).data or []
        companies.extend(data)
        if len(data) < limit:
            break
        start += limit

    # Format to match frontend: list of {"label": company_name, "value": company_name}
    # Sort them by company name alphabetically
    sorted_companies = sorted(
        [{"label": c["company_name"], "value": c["company_name"]} for c in companies if c.get("company_name")],
        key=lambda x: x["label"].lower()
    )
    return sorted_companies



"""Hybrid ESG document retrieval with deterministic extractive answers.

This module deliberately performs no LLM generation. It retrieves evidence,
fuses dense and keyword ranks, expands child chunks to parent context, and
returns short source-linked extracts.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import os
import re
from typing import Any, Protocol, Sequence

from app.config import (
    SUPABASE_SERVICE_ROLE_KEY,
    SUPABASE_URL,
    WORKSPACE_ID,
    validate_database_config,
)


DENSE_LIMIT = 30
KEYWORD_LIMIT = 30
FINAL_LIMIT = 8
RRF_K = 60

CHUNK_FIELDS = (
    "id, document_id, workspace_id, parent_chunk_id, corpus_type, company, sector, "
    "reporting_year, report_type, section_title, page_number, chunk_index, "
    "chunk_level, chunk_text, chunk_type, intent_label"
)

STOP_WORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "did", "do", "does",
    "for", "from", "has", "have", "how", "in", "is", "it", "of", "on", "or",
    "our", "the", "their", "to", "was", "were", "what", "when", "why", "with",
    "about", "answer", "brief", "briefly", "company", "document", "documents",
    "esg", "explain", "find", "give", "mention", "report", "reports", "say",
    "says", "show", "summarise", "summarize", "tell",
}

PHRASE_EXPANSIONS = {
    "human rights": ["human rights", "human", "rights"],
    "employee wellbeing": ["employee wellbeing", "employee well-being", "wellbeing", "well-being"],
    "employee well-being": ["employee wellbeing", "employee well-being", "wellbeing", "well-being"],
    "wellbeing": ["wellbeing", "well-being"],
    "well-being": ["wellbeing", "well-being"],
    "health and safety": ["health safety", "health", "safety"],
    "training and awareness": ["training awareness", "training", "awareness"],
}

METADATA_PREFIXES = (
    "company:",
    "reporting year:",
    "source file:",
    "pages:",
    "section:",
    "disclosure topic:",
    "principle:",
    "esg topics:",
    "kpi topics:",
    "disclosure titles:",
)

LOW_VALUE_EXTRACT_PATTERNS = (
    "structured table available",
    "reasonable assurance has been carried out",
    "limited assurance has been carried out",
    "integrated annual report",
    "business responsibility & sustainability reporting",
    "business responsibility and sustainability reporting",
    "annexure i",
    "cross reference to",
    "nothing in the engagement or this statement",
    "assurance report",
    "total waste generated",
    "waste intensity",
    "by nature of disposal",
    "attribute parameter",
    "membership of employees and workers",
    "current financial year and the previous financial year",
)

OCR_DISPLAY_FIXES = (
    (re.compile(r"\bfle\b", flags=re.IGNORECASE), "file"),
    (re.compile(r"\bOffcer\b"), "Officer"),
    (re.compile(r"\bthengive\b", flags=re.IGNORECASE), "then give"),
    (re.compile(r"\bbynature\b", flags=re.IGNORECASE), "by nature"),
)


@dataclass(frozen=True)
class DocumentFilters:
    workspace_id: str
    company: str | None = None
    reporting_year: str | None = None
    corpus_type: str | None = None


class EmbeddingProvider(Protocol):
    def embed(self, text: str) -> list[float]: ...


class DocumentSearchBackend(Protocol):
    def dense_search(
        self,
        query_embedding: Sequence[float],
        filters: DocumentFilters,
        limit: int,
    ) -> list[dict[str, Any]]: ...

    def keyword_search(
        self,
        query: str,
        filters: DocumentFilters,
        limit: int,
    ) -> list[dict[str, Any]]: ...

    def fetch_chunks(
        self,
        chunk_ids: Sequence[str],
        workspace_id: str,
    ) -> list[dict[str, Any]]: ...


class OpenAIEmbeddingProvider:
    """Query embeddings only; this provider never invokes text generation."""

    def __init__(self, api_key: str | None = None, model: str | None = None):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.model = model or os.getenv("DOCUMENT_EMBEDDING_MODEL", "text-embedding-3-small")
        dimensions = (os.getenv("DOCUMENT_EMBEDDING_DIMENSIONS") or "").strip()
        self.dimensions = int(dimensions) if dimensions.isdigit() else None

    def embed(self, text: str) -> list[float]:
        if not self.api_key:
            raise RuntimeError("OPENAI_API_KEY is required for dense document retrieval")
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise RuntimeError("Install the 'openai' package for query embeddings") from exc
        request: dict[str, Any] = {"model": self.model, "input": [text]}
        if self.dimensions:
            request["dimensions"] = self.dimensions
        response = OpenAI(api_key=self.api_key).embeddings.create(**request)
        return list(response.data[0].embedding)


class BGEEmbeddingProvider:
    """Local query embeddings for BGE-M3 / BAAI/bge-m3 document vectors."""

    _model_cache: dict[str, Any] = {}

    def __init__(self, model: str | None = None):
        self.model_name = model or os.getenv("DOCUMENT_EMBEDDING_MODEL", "BAAI/bge-m3")
        self.query_prefix = os.getenv("BGE_QUERY_PREFIX", "")
        self.normalize = os.getenv("BGE_NORMALIZE_EMBEDDINGS", "true").lower() not in {"0", "false", "no"}
        self.backend = os.getenv("BGE_BACKEND", "auto").strip().lower()
        self.use_fp16 = os.getenv("BGE_USE_FP16", "false").lower() in {"1", "true", "yes"}
        batch_size = (os.getenv("BGE_QUERY_BATCH_SIZE") or "").strip()
        self.batch_size = int(batch_size) if batch_size.isdigit() else 1

    def _model(self):
        cache_key = f"{self.backend}:{self.model_name}:{self.use_fp16}"
        if cache_key in self._model_cache:
            return self._model_cache[cache_key]

        if self.backend in {"auto", "flag", "flagembedding"}:
            try:
                from FlagEmbedding import BGEM3FlagModel
                model = BGEM3FlagModel(self.model_name, use_fp16=self.use_fp16)
                self._model_cache[cache_key] = ("flagembedding", model)
                return self._model_cache[cache_key]
            except ImportError:
                if self.backend in {"flag", "flagembedding"}:
                    raise RuntimeError(
                        "Install 'FlagEmbedding' to use BGE_BACKEND=flagembedding"
                    )

        if self.backend in {"auto", "sentence-transformers", "sentence_transformers", "st"}:
            try:
                from sentence_transformers import SentenceTransformer
            except ImportError as exc:
                raise RuntimeError(
                    "Install 'sentence-transformers' to use BGE-M3 dense document retrieval"
                ) from exc
            model = SentenceTransformer(self.model_name)
            self._model_cache[cache_key] = ("sentence-transformers", model)
            return self._model_cache[cache_key]

        raise RuntimeError(
            f"Unsupported BGE_BACKEND={self.backend!r}; use 'auto', 'flagembedding', or 'sentence-transformers'"
        )

    def embed(self, text: str) -> list[float]:
        query_text = f"{self.query_prefix}{text}" if self.query_prefix else text
        backend_name, model = self._model()
        if backend_name == "flagembedding":
            encoded = model.encode(
                [query_text],
                batch_size=self.batch_size,
                max_length=int(os.getenv("BGE_MAX_LENGTH", "8192")),
                return_dense=True,
                return_sparse=False,
                return_colbert_vecs=False,
            )
            vector = encoded["dense_vecs"][0]
        else:
            vector = model.encode(
                query_text,
                normalize_embeddings=self.normalize,
                batch_size=self.batch_size,
                show_progress_bar=False,
            )
        values = vector.tolist() if hasattr(vector, "tolist") else vector
        return [float(value) for value in values]


def get_embedding_provider() -> EmbeddingProvider | None:
    provider = os.getenv("DOCUMENT_EMBEDDING_PROVIDER", "bge-m3").strip().lower()
    if provider in {"", "none", "disabled", "off", "false"}:
        return None
    if provider in {"bge", "bge-m3", "baai/bge-m3"}:
        return BGEEmbeddingProvider()
    if provider == "openai":
        return OpenAIEmbeddingProvider()
    raise RuntimeError(
        f"Unsupported DOCUMENT_EMBEDDING_PROVIDER={provider!r}; use 'bge-m3', 'openai', or 'none'"
    )


_document_supabase_client = None


def get_document_supabase_client():
    global _document_supabase_client
    if _document_supabase_client is None:
        validate_database_config()
        try:
            from supabase import create_client
        except ImportError as exc:
            raise RuntimeError("Install the 'supabase' package before starting the API") from exc
        _document_supabase_client = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
    return _document_supabase_client


def _keyword_query_variants(query: str) -> list[str]:
    """Generate robust keyword queries from natural-language user questions.

    Supabase/Postgres websearch queries can become too strict when we pass the
    full user question, because filler words such as "report" or "say" may be
    treated as required terms. The variants below keep ESG terms while preserving
    the original query as the first attempt.
    """
    clean = re.sub(r"\s+", " ", query or "").strip()
    if not clean:
        return []

    lowered = clean.lower()
    variants = [clean]

    expanded_phrases: list[str] = []
    for phrase, expansions in PHRASE_EXPANSIONS.items():
        if phrase in lowered:
            expanded_phrases.extend(expansions)
    if expanded_phrases:
        variants.append(" OR ".join(
            f'"{phrase}"' if " " in phrase else phrase
            for phrase in dict.fromkeys(expanded_phrases)
        ))

    tokens = [
        token
        for token in re.findall(r"[a-z0-9][a-z0-9-]*", lowered)
        if len(token) > 2 and token not in STOP_WORDS
    ]
    if tokens:
        variants.append(" ".join(tokens))
    if len(tokens) > 1:
        variants.append(" OR ".join(dict.fromkeys(tokens)))

    return list(dict.fromkeys(variants))


class SupabaseDocumentSearchBackend:
    """Supabase adapter for the two document search RPCs and parent lookup."""

    def __init__(self, client=None):
        self.client = client or get_document_supabase_client()
        self.table_name = os.getenv("DOCUMENT_CHUNKS_TABLE", "brsr_document_embeddings")
        self.dense_rpc = os.getenv("DOCUMENT_DENSE_RPC", "match_document_chunks")
        self.keyword_rpc = os.getenv("DOCUMENT_KEYWORD_RPC", "search_document_chunks_keyword")

    @staticmethod
    def _rpc_params(filters: DocumentFilters, limit: int) -> dict[str, Any]:
        return {
            "match_count": limit,
            "filter_workspace_id": filters.workspace_id,
            "filter_company": filters.company,
            "filter_reporting_year": filters.reporting_year,
            "filter_corpus_type": filters.corpus_type,
        }

    def dense_search(self, query_embedding, filters, limit):
        params = self._rpc_params(filters, limit)
        params["query_embedding"] = list(query_embedding)
        return self.client.rpc(self.dense_rpc, params).execute().data or []

    def keyword_search(self, query, filters, limit):
        variants = _keyword_query_variants(query)
        rpc_failed = False
        for keyword_query in variants:
            params = self._rpc_params(filters, limit)
            params["search_query"] = keyword_query
            try:
                rows = self.client.rpc(self.keyword_rpc, params).execute().data or []
                if rows:
                    return rows
            except Exception:
                rpc_failed = True
                break

        if rpc_failed or variants:
            keyword_query = variants[-1] if variants else query
            request = (
                self.client.table(self.table_name)
                .select(CHUNK_FIELDS)
            )
            request = self._apply_workspace_filter(request, filters.workspace_id)
            if filters.company:
                request = request.ilike("company", f"%{filters.company}%")
            if filters.reporting_year:
                request = request.eq("reporting_year", filters.reporting_year)
            if filters.corpus_type:
                request = request.eq("corpus_type", filters.corpus_type)
            return (
                request.limit(limit)
                .text_search(
                    "search_text",
                    keyword_query,
                    options={"config": "english", "type": "web_search"},
                )
                .execute()
            ).data or []
        return []

    def fetch_chunks(self, chunk_ids, workspace_id):
        ids = [str(value) for value in chunk_ids if value]
        if not ids:
            return []
        request = (
            self.client.table(self.table_name)
            .select(CHUNK_FIELDS)
            .in_("id", ids)
        )
        request = self._apply_workspace_filter(request, workspace_id)
        rows = request.execute().data or []
        if rows:
            return rows
        return (
            self.client.table(self.table_name)
            .select(CHUNK_FIELDS)
            .in_("id", ids)
            .execute()
        ).data or []

    @staticmethod
    def _apply_workspace_filter(request, workspace_id: str):
        if not workspace_id:
            return request
        return request.or_(f"workspace_id.eq.{workspace_id},workspace_id.is.null")


def _chunk_key(row: dict[str, Any]) -> str:
    if row.get("id"):
        return str(row["id"])
    identity = "|".join(
        str(row.get(field) or "")
        for field in ("document_id", "page_number", "chunk_index", "chunk_text")
    )
    return hashlib.sha1(identity.encode("utf-8")).hexdigest()


def rrf_fuse(
    dense_rows: Sequence[dict[str, Any]],
    keyword_rows: Sequence[dict[str, Any]],
    *,
    rrf_k: int = RRF_K,
) -> list[dict[str, Any]]:
    """Reciprocal-rank fusion with id-based deduplication."""
    fused: dict[str, dict[str, Any]] = {}
    for source, rows in (("dense", dense_rows), ("keyword", keyword_rows)):
        seen: set[str] = set()
        for rank, raw_row in enumerate(rows, start=1):
            row = dict(raw_row)
            key = _chunk_key(row)
            if key in seen:
                continue
            seen.add(key)
            if key not in fused:
                row["retrieval_score"] = 0.0
                row["retrieval_sources"] = []
                fused[key] = row
            fused[key]["retrieval_score"] += 1.0 / (rrf_k + rank)
            fused[key]["retrieval_sources"].append(source)
    return sorted(
        fused.values(),
        key=lambda row: (-float(row.get("retrieval_score") or 0), _chunk_key(row)),
    )


def _query_tokens(text: str) -> set[str]:
    return {
        token
        for token in re.findall(r"[a-z0-9]+", (text or "").lower())
        if len(token) > 1 and token not in STOP_WORDS
    }


def _expand_parent_context(
    rows: list[dict[str, Any]],
    backend: DocumentSearchBackend,
    workspace_id: str,
) -> list[dict[str, Any]]:
    parent_ids = sorted({
        str(row["parent_chunk_id"])
        for row in rows
        if row.get("parent_chunk_id") and str(row.get("parent_chunk_id")) != str(row.get("id"))
    })
    parents = {
        str(row.get("id")): row
        for row in backend.fetch_chunks(parent_ids, workspace_id)
        if row.get("id")
    } if parent_ids else {}
    for row in rows:
        parent = parents.get(str(row.get("parent_chunk_id")))
        row["context_text"] = (
            parent.get("chunk_text") if parent and parent.get("chunk_text") else row.get("chunk_text")
        )
        if parent:
            row["parent_context_chunk_id"] = parent.get("id")
    return rows


def _rerank(query: str, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    query_tokens = _query_tokens(query)
    max_rrf = max((float(row.get("retrieval_score") or 0) for row in rows), default=1.0)
    for row in rows:
        text_tokens = _query_tokens(str(row.get("context_text") or row.get("chunk_text") or ""))
        lexical = len(query_tokens & text_tokens) / max(len(query_tokens), 1)
        rrf_component = float(row.get("retrieval_score") or 0) / max(max_rrf, 1e-12)
        row["rerank_score"] = round((0.65 * lexical) + (0.35 * rrf_component), 8)
    return sorted(
        rows,
        key=lambda row: (-float(row.get("rerank_score") or 0), _chunk_key(row)),
    )


def retrieve_document_chunks(
    query: str,
    *,
    company: str | None = None,
    reporting_year: str | None = None,
    corpus_type: str | None = None,
    backend: DocumentSearchBackend | None = None,
    embedding_provider: EmbeddingProvider | None = None,
    workspace_id: str | None = None,
    final_limit: int = FINAL_LIMIT,
) -> dict[str, Any]:
    """Run hybrid retrieval and return ranked citation-ready context blocks."""
    clean_query = re.sub(r"\s+", " ", query or "").strip()
    if not clean_query:
        return {"chunks": [], "warnings": ["Document query is empty"], "search_modes": []}

    resolved_workspace_id = workspace_id or WORKSPACE_ID
    if not resolved_workspace_id:
        raise RuntimeError("WORKSPACE_ID is required for document retrieval")
    backend = backend or SupabaseDocumentSearchBackend()
    filters = DocumentFilters(
        workspace_id=resolved_workspace_id,
        company=company,
        reporting_year=reporting_year,
        corpus_type=corpus_type,
    )
    warnings: list[str] = []
    dense_rows: list[dict[str, Any]] = []
    keyword_rows: list[dict[str, Any]] = []

    provider = embedding_provider
    if provider is None:
        try:
            provider = get_embedding_provider()
        except Exception as exc:
            warnings.append(f"Dense retrieval provider unavailable: {exc}")
    if provider is None:
        warnings.append("Dense retrieval skipped because no query embedding provider is configured")
    else:
        try:
            query_embedding = provider.embed(clean_query)
            dense_rows = backend.dense_search(query_embedding, filters, DENSE_LIMIT)
        except Exception as exc:
            warnings.append(f"Dense retrieval unavailable: {exc}")

    try:
        keyword_rows = backend.keyword_search(clean_query, filters, KEYWORD_LIMIT)
    except Exception as exc:
        warnings.append(f"Keyword retrieval unavailable: {exc}")

    search_modes = []
    if dense_rows:
        search_modes.append("dense")
    if keyword_rows:
        search_modes.append("keyword")
    fused = rrf_fuse(dense_rows, keyword_rows)
    expanded = _expand_parent_context(fused, backend, resolved_workspace_id)
    ranked = _rerank(clean_query, expanded)[: max(1, min(final_limit, 10))]
    return {"chunks": ranked, "warnings": warnings, "search_modes": search_modes}


def _strip_chunk_metadata(text: str) -> str:
    lines: list[str] = []
    for raw_line in (text or "").splitlines():
        line = raw_line.strip()
        if not line:
            if lines and lines[-1] != "":
                lines.append("")
            continue
        lowered = line.lower()
        if any(lowered.startswith(prefix) for prefix in METADATA_PREFIXES):
            continue
        if lowered.startswith("### ") or lowered.startswith("## "):
            continue
        lines.append(line)

    clean = "\n".join(lines)
    clean = re.sub(
        r"\[Structured table available as a separate table chunk[^\]]*\]",
        " ",
        clean,
        flags=re.IGNORECASE,
    )
    clean = re.sub(r"\bIntegrated Annual Report\s+\d{4}-\d{2}\s+\d+\b", " ", clean)
    clean = re.sub(r"[*_`]+", "", clean)
    return re.sub(r"\n{3,}", "\n\n", clean).strip()


def _sentences(text: str) -> list[str]:
    clean = _strip_chunk_metadata(text)
    if not clean:
        return []
    clean = re.sub(r"\s*\|\s*", " | ", clean)
    raw_parts = re.split(
        r"(?<=[.!?])\s+|\n{2,}|\n(?=\s*(?:[-*•]|\d+[.)]))",
        clean,
    )
    sentences = []
    for part in raw_parts:
        sentence = re.sub(r"\s+", " ", part).strip(" -•\t")
        if len(sentence) >= 24:
            sentences.append(sentence)
    return sentences


def _extract_score(query_tokens: set[str], candidate: str) -> tuple[float, int]:
    lowered = candidate.lower()
    candidate_tokens = _query_tokens(candidate)
    overlap = len(query_tokens & candidate_tokens)
    phrase_hits = sum(
        1
        for phrase in (
            "human rights",
            "wellbeing",
            "well-being",
            "well being",
            "employee",
            "employees",
            "workers",
            "grievance",
            "grievances",
            "training",
            "policy",
            "safe",
            "inclusive",
            "equal opportunity",
            "non-discrimination",
        )
        if phrase in lowered
    )
    low_value_penalty = sum(
        1 for pattern in LOW_VALUE_EXTRACT_PATTERNS if pattern in lowered
    )
    length_bonus = min(len(candidate), 420) / 420
    return (
        (2.0 * overlap) + (1.25 * phrase_hits) + length_bonus - (2.5 * low_value_penalty),
        len(candidate_tokens),
    )


def _is_low_quality_extract(candidate: str) -> bool:
    lowered = candidate.lower()
    words = re.findall(r"[a-z0-9]+", lowered)
    if len(words) < 9:
        return True
    if candidate.strip().endswith("?"):
        return True
    if re.match(
        r"^(is|are|do|does|did|what|whether|provide|describe|details of|particulars\b)",
        lowered,
    ):
        return True
    if any(pattern in lowered for pattern in ("http", ".html", "codesandpolicies", "positionstatement")):
        return True
    if "@" in candidate:
        return True
    if "position statement principle" in lowered:
        return True
    if re.search(r"\bprinciple\s+\d+\s*:", lowered) and len(words) < 14:
        return True
    if any(pattern in lowered for pattern in LOW_VALUE_EXTRACT_PATTERNS):
        return True
    if candidate.count("|") > 3:
        return True
    if re.search(r"\b(fy|financial year)\s*20\d{2}", lowered) and candidate.count("-") >= 3:
        return True
    numeric_tokens = re.findall(r"\b\d+(?:[.,]\d+)?%?\b", candidate)
    if len(numeric_tokens) >= 5 and len(numeric_tokens) >= len(words) / 4:
        return True
    return False


def _is_relevant_extract(candidate: str, query_tokens: set[str]) -> bool:
    lowered = candidate.lower()
    candidate_tokens = _query_tokens(candidate)
    overlap = query_tokens & candidate_tokens
    if len(overlap) >= 2:
        return True
    if "human rights" in lowered:
        return True
    if any(phrase in lowered for phrase in ("wellbeing", "well-being", "well being")):
        return True
    if any(
        phrase in lowered
        for phrase in (
            "equal opportunity",
            "equal opportunities",
            "non-discrimination",
            "discrimination",
            "sexual harassment",
            "whistleblow",
            "grievance redressal",
        )
    ):
        return True
    workforce_context = any(
        token in lowered
        for token in (
            "employee",
            "employees",
            "worker",
            "workers",
            "workforce",
            "team member",
            "team members",
            "complainant",
            "complainants",
        )
    )
    people_policy_context = any(
        token in lowered
        for token in (
            "grievance",
            "grievances",
            "complaint",
            "complaints",
            "concern",
            "concerns",
            "policy",
            "policies",
            "safe",
            "safety",
            "accessible",
            "accessibility",
            "discrimination",
            "harassment",
            "training",
            "whistle",
            "equal opportunity",
            "non-discrimination",
            "inclusive",
            "accessibility",
        )
    )
    return workforce_context and people_policy_context


def _clean_extract_text(text: str) -> str:
    clean = text
    for pattern, replacement in OCR_DISPLAY_FIXES:
        clean = pattern.sub(replacement, clean)
    return clean


def _best_extract(query: str, row: dict[str, Any], max_chars: int = 420) -> str:
    query_tokens = _query_tokens(query)
    candidates = _sentences(str(row.get("context_text") or row.get("chunk_text") or ""))
    candidates = [candidate for candidate in candidates if not _is_low_quality_extract(candidate)]
    candidates = [candidate for candidate in candidates if _is_relevant_extract(candidate, query_tokens)]
    if not candidates:
        return ""
    best = max(
        enumerate(candidates),
        key=lambda item: (
            *_extract_score(query_tokens, item[1]),
            -item[0],
        ),
    )[1]
    if len(best) <= max_chars:
        return _clean_extract_text(best)
    shortened = best[: max_chars - 1].rsplit(" ", 1)[0].rstrip(" ,;:")
    return _clean_extract_text(f"{shortened}...")
    return f"{shortened}…"


def _citation_document(row: dict[str, Any]) -> str:
    return str(
        row.get("document")
        or row.get("document_title")
        or row.get("report_type")
        or row.get("document_id")
        or "Uploaded ESG document"
    )


def _has_citation_metadata(row: dict[str, Any]) -> bool:
    return bool(
        row.get("id")
        and row.get("document_id")
        and row.get("page_number") is not None
        and row.get("section_title")
    )


def format_document_answer(query: str, retrieval: dict[str, Any]) -> dict[str, Any]:
    """Build an extractive answer in which every statement has a citation."""
    rows = retrieval.get("chunks") or []
    citations: list[dict[str, Any]] = []
    answer_lines: list[str] = []
    retrieved_chunks: list[dict[str, Any]] = []
    seen_extracts: set[str] = set()
    missing_citation_metadata = 0

    for row in rows:
        if not _has_citation_metadata(row):
            missing_citation_metadata += 1
            continue
        extract = _best_extract(query, row)
        normalized_extract = re.sub(r"\W+", " ", extract.lower()).strip()
        if not extract or normalized_extract in seen_extracts:
            continue
        seen_extracts.add(normalized_extract)
        source_id = f"S{len(citations) + 1}"
        citation = {
            "source_id": source_id,
            "source_chunk_id": row.get("id"),
            "document_id": row.get("document_id"),
            "company": row.get("company"),
            "document": _citation_document(row),
            "page": row.get("page_number"),
            "section": row.get("section_title"),
            "quote": extract,
        }
        citations.append(citation)
        answer_lines.append(f"{extract} [{source_id}]")
        retrieved_chunks.append({
            "source_id": source_id,
            "chunk_id": row.get("id"),
            "parent_chunk_id": row.get("parent_context_chunk_id") or row.get("parent_chunk_id"),
            "document_id": row.get("document_id"),
            "company": row.get("company"),
            "reporting_year": row.get("reporting_year"),
            "page": row.get("page_number"),
            "section": row.get("section_title"),
            "text": row.get("context_text") or row.get("chunk_text"),
            "score": row.get("rerank_score"),
            "retrieval_sources": row.get("retrieval_sources", []),
        })
        if len(citations) >= 3:
            break

    warnings = list(retrieval.get("warnings", []))
    if missing_citation_metadata:
        warnings.append(
            f"Excluded {missing_citation_metadata} chunk(s) without document, page, section, and chunk metadata"
        )

    if not citations:
        return {
            "answer": "I could not find enough evidence in the indexed documents to answer this question.",
            "citations": [],
            "retrieved_chunks": [],
            "confidence": "low",
            "warnings": warnings,
        }

    modes = set(retrieval.get("search_modes") or [])
    confidence = "high" if len(citations) >= 2 and {"dense", "keyword"}.issubset(modes) else "medium"
    return {
        "answer": "\n\n".join(answer_lines),
        "citations": citations,
        "retrieved_chunks": retrieved_chunks,
        "confidence": confidence,
        "warnings": warnings,
    }


def retrieve_and_format_document_answer(query: str, **kwargs) -> dict[str, Any]:
    retrieval = retrieve_document_chunks(query, **kwargs)
    return format_document_answer(query, retrieval)

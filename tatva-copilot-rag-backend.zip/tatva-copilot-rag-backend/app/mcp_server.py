import logging
from mcp.server.fastmcp import FastMCP
from app.kpi_retriever import (
    retrieve_kpis,
    retrieve_kpis_for_companies,
    format_kpi_answer,
    format_comparison_answer,
)
from app.document_retriever import retrieve_document_chunks, format_document_answer

logger = logging.getLogger(__name__)

# Initialize the FastMCP server
mcp = FastMCP("Tatva ESG Copilot")

@mcp.tool()
def search_esg_kpis(
    company_names: list[str], 
    query: str, 
    reporting_year: str = None
) -> dict:
    """Retrieve verified numerical ESG KPI metrics (emissions, employee ratios, water usage, etc.)
    and YoY changes. Supports single-company or multi-company comparison.
    
    Args:
        company_names: List of one or more company names to search (e.g. ["Siemens Limited"]).
        query: The user's query about specific metrics (e.g. "Scope 1 emissions").
        reporting_year: Optional reporting year filter (e.g. "FY 2022-23").
    """
    logger.info(f"MCP Tool 'search_esg_kpis' called for {company_names} with query '{query}'")
    
    # Filter empty strings or None values
    companies = [c for c in company_names if c]
    if not companies:
        return {
            "answer": "No companies specified for KPI lookup.",
            "kpi_facts": [],
            "citations": [],
            "confidence": "low",
        }

    if len(companies) > 1:
        # Multi-company comparison path
        rows = retrieve_kpis_for_companies(
            company_names=companies,
            query=query,
            reporting_year=reporting_year,
        )
        result = format_comparison_answer(
            company_names=companies,
            query=query,
            rows=rows,
        )
    else:
        # Single company path
        company = companies[0]
        rows = retrieve_kpis(
            company_name=company,
            query=query,
            reporting_year=reporting_year,
        )
        result = format_kpi_answer(
            company_name=company,
            query=query,
            rows=rows,
        )
        
    return {
        "answer": result.get("answer", ""),
        "kpi_facts": result.get("kpi_facts", []),
        "citations": result.get("citations", []),
        "confidence": result.get("confidence", "low"),
        "warnings": result.get("warnings", []),
    }


@mcp.tool()
def search_esg_documents(
    query: str, 
    company_name: str = None, 
    reporting_year: str = None,
    peer_companies: list[str] = None
) -> dict:
    """Search unstructured ESG PDF documents (policies, strategy descriptions, text explanations, disclosures).
    Use this when the query asks 'why', 'how', 'explain', or seeks policy details.
    
    Args:
        query: Natural language query seeking textual explanations or policies.
        company_name: The primary company name to filter by (optional).
        reporting_year: Optional reporting year filter (e.g. "FY 2022-23").
        peer_companies: Optional list of peer company names to search alongside the primary company.
    """
    logger.info(f"MCP Tool 'search_esg_documents' called for {company_name} with query '{query}'")
    
    # Gather all companies
    companies = []
    if company_name:
        companies.append(company_name)
    if peer_companies:
        companies.extend(peer_companies)
        
    # Clean list
    companies = list(dict.fromkeys([c for c in companies if c]))
    
    all_chunks = []
    all_citations = []
    all_warnings = []
    individual_answers = []
    
    # If no company is provided, search globally (e.g., regulatory queries)
    if not companies:
        result = format_document_answer(
            query,
            retrieve_document_chunks(
                query,
                company=None,
                reporting_year=reporting_year,
            )
        )
        return {
            "answer": result.get("answer", ""),
            "citations": result.get("citations", []),
            "retrieved_chunks": result.get("retrieved_chunks", []),
            "confidence": result.get("confidence", "low"),
            "warnings": result.get("warnings", []),
        }

    for comp in companies:
        retrieval = retrieve_document_chunks(
            query,
            company=comp,
            reporting_year=reporting_year,
        )
        result = format_document_answer(query, retrieval)
        
        # Map source IDs to prevent collisions in multi-company queries
        current_count = len(all_citations)
        id_map = {}
        for idx, citation in enumerate(result.get("citations", [])):
            old_id = citation["source_id"]
            new_id = f"S{current_count + idx + 1}"
            id_map[old_id] = new_id
            
            new_citation = dict(citation)
            new_citation["source_id"] = new_id
            all_citations.append(new_citation)
            
        for chunk in result.get("retrieved_chunks", []):
            old_id = chunk["source_id"]
            new_id = id_map.get(old_id, old_id)
            new_chunk = dict(chunk)
            new_chunk["source_id"] = new_id
            all_chunks.append(new_chunk)
            
        comp_answer = result.get("answer", "")
        for old_id, new_id in id_map.items():
            comp_answer = comp_answer.replace(f"[{old_id}]", f"[{new_id}]")
            
        if comp_answer:
            individual_answers.append(comp_answer)
            
        all_warnings.extend(result.get("warnings", []))
        
    fallback_answer = "\n\n".join(individual_answers)
    
    # We return the raw materials so the host/LLM client can process them
    return {
        "answer": fallback_answer,
        "citations": all_citations,
        "retrieved_chunks": all_chunks,
        "confidence": "high" if len(all_citations) >= 2 else "medium",
        "warnings": sorted(list(set(all_warnings))),
    }


@mcp.tool()
def retrieve_regulations(
    query: str,
    framework: str = "BRSR"
) -> dict:
    """Retrieve official regulatory guidance, guidelines, and frameworks (e.g. BRSR, GRI).
    
    Args:
        query: The specific regulatory topic or question (e.g. "Scope 3 emissions requirements").
        framework: The targeted ESG framework (e.g. "BRSR").
    """
    logger.info(f"MCP Tool 'retrieve_regulations' called with query '{query}' for framework '{framework}'")
    retrieval = retrieve_document_chunks(
        query,
        company=None,
        corpus_type="regulatory",
    )
    result = format_document_answer(query, retrieval)
    return {
        "answer": result.get("answer", ""),
        "citations": result.get("citations", []),
        "retrieved_chunks": result.get("retrieved_chunks", []),
        "confidence": result.get("confidence", "low"),
        "warnings": result.get("warnings", []),
    }


@mcp.tool()
def retrieve_benchmarks(
    query: str,
    peer_companies: list[str] = None
) -> dict:
    """Retrieve industry best-practice disclosures and peer ESG benchmarks.
    
    Args:
        query: The ESG topic to benchmark (e.g. "water recycling targets").
        peer_companies: Optional list of peer company names to filter disclosures.
    """
    logger.info(f"MCP Tool 'retrieve_benchmarks' called with query '{query}' for peers {peer_companies}")
    
    companies = [c for c in peer_companies if c] if peer_companies else []
    
    all_chunks = []
    all_citations = []
    all_warnings = []
    individual_answers = []
    
    # If no peer companies, search globally but look for best practices
    if not companies:
        retrieval = retrieve_document_chunks(
            f"best practice benchmark {query}",
            company=None,
        )
        result = format_document_answer(query, retrieval)
        return {
            "answer": result.get("answer", ""),
            "citations": result.get("citations", []),
            "retrieved_chunks": result.get("retrieved_chunks", []),
            "confidence": result.get("confidence", "low"),
            "warnings": result.get("warnings", []),
        }
        
    for comp in companies:
        retrieval = retrieve_document_chunks(
            query,
            company=comp,
        )
        result = format_document_answer(query, retrieval)
        
        current_count = len(all_citations)
        id_map = {}
        for idx, citation in enumerate(result.get("citations", [])):
            old_id = citation["source_id"]
            new_id = f"B{current_count + idx + 1}"
            id_map[old_id] = new_id
            
            new_citation = dict(citation)
            new_citation["source_id"] = new_id
            all_citations.append(new_citation)
            
        for chunk in result.get("retrieved_chunks", []):
            old_id = chunk["source_id"]
            new_id = id_map.get(old_id, old_id)
            new_chunk = dict(chunk)
            new_chunk["source_id"] = new_id
            all_chunks.append(new_chunk)
            
        comp_answer = result.get("answer", "")
        for old_id, new_id in id_map.items():
            comp_answer = comp_answer.replace(f"[{old_id}]", f"[{new_id}]")
            
        if comp_answer:
            individual_answers.append(f"Benchmark from {comp}:\n{comp_answer}")
            
        all_warnings.extend(result.get("warnings", []))
        
    return {
        "answer": "\n\n".join(individual_answers),
        "citations": all_citations,
        "retrieved_chunks": all_chunks,
        "confidence": "high" if len(all_citations) >= 2 else "medium",
        "warnings": sorted(list(set(all_warnings))),
    }


@mcp.tool()
def analyze_gaps(
    primary_company: str,
    peer_companies: list[str],
    topic: str
) -> dict:
    """Compare disclosures of a primary company against peer disclosures on a specific topic.
    
    Args:
        primary_company: Name of the target company.
        peer_companies: List of peer company names to compare against.
        topic: The ESG topic or metric to compare (e.g. "Scope 3 supplier data", "human rights policy").
    """
    logger.info(f"MCP Tool 'analyze_gaps' called for primary '{primary_company}' vs peers {peer_companies} on topic '{topic}'")
    
    # Fetch primary company disclosures
    primary_retrieval = retrieve_document_chunks(topic, company=primary_company)
    primary_result = format_document_answer(topic, primary_retrieval)
    
    # Fetch peers disclosures
    peer_results = {}
    for peer in peer_companies:
        if not peer:
            continue
        peer_retrieval = retrieve_document_chunks(topic, company=peer)
        peer_res = format_document_answer(topic, peer_retrieval)
        peer_results[peer] = peer_res.get("answer", "No disclosure found.")
        
    comparison_text = [
        f"PRIMARY COMPANY ({primary_company}) DISCLOSURES FOR '{topic}':\n{primary_result.get('answer', 'No disclosure found.')}"
    ]
    for peer, peer_ans in peer_results.items():
         comparison_text.append(f"PEER COMPANY ({peer}) DISCLOSURES FOR '{topic}':\n{peer_ans}")
        
    # Aggregate citations and chunks
    all_citations = list(primary_result.get("citations", []))
    all_chunks = list(primary_result.get("retrieved_chunks", []))
    all_warnings = list(primary_result.get("warnings", []))
    
    return {
        "comparison_data": "\n\n---\n\n".join(comparison_text),
        "citations": all_citations,
        "retrieved_chunks": all_chunks,
        "warnings": all_warnings,
    }


@mcp.tool()
def draft_disclosure(
    company_name: str,
    topic: str,
    retrieved_context: str,
    kpis: dict = None
) -> dict:
    """Generate draft disclosures (climate governance, board oversight, energy metrics) aligned with frameworks.
    
    Args:
        company_name: The company name.
        topic: The disclosure topic/section (e.g. "Board climate oversight narrative").
        retrieved_context: Policy requirements, guidelines, or peer templates.
        kpis: Key numerical metrics (optional dictionary) to mention or compile in the draft.
    """
    logger.info(f"MCP Tool 'draft_disclosure' called for {company_name} on topic '{topic}'")
    
    kpi_str = ""
    if kpis:
        kpi_str = "\n".join(f"- {k}: {v}" for k, v in kpis.items())
        
    return {
        "draft_prompt_context": (
            f"Drafting ESG Disclosure Section for {company_name}\n"
            f"Section Topic: {topic}\n"
            f"Relevant KPIs:\n{kpi_str or 'None'}\n"
            f"Framework Requirements & Context:\n{retrieved_context}"
        )
    }

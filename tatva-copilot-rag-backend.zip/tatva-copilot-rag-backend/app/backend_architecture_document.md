# tatva.copilot Backend Architecture Document

This document provides a comprehensive overview of the backend architecture of **tatva.copilot**, an agentic ESG (Environmental, Social, and Governance) Analysis and Report Generation platform.

---

## 1. System Overview & Tech Stack

The backend is built as an agentic RAG (Retrieval-Augmented Generation) system. It combines structured databases (Supabase for relational metrics and vector storage) with LLM orchestration (Groq API) and uses the **Model Context Protocol (MCP)** to expose functional tools.

### Tech Stack
* **Framework**: FastAPI (Python 3.10+)
* **Database**: Supabase (Postgres with pgvector extension)
* **LLM Provider**: Groq (Llama-3.1-8b-instant, Llama-3.3-70b-versatile)
* **MCP Library**: FastMCP (Model Context Protocol Python SDK)
* **Vector Embeddings**: Supabase REST API & database search functions

---

## 2. System Architecture & Component Mapping

```mermaid
graph TD
    UI[Frontend Client /static/index.html] -->|REST API Requests| API[FastAPI Server app/main.py]
    API -->|SSE /mcp| MCP[MCP Server app/mcp_server.py]
    API -->|Chat /chat| LLM_Chat[Agent Loop app/llm.py]
    API -->|Report /chat/report| LLM_Report[Report Pipeline app/llm.py]
    
    LLM_Chat -->|Dynamic Tool Calls| MCP
    MCP -->|Retrieve KPIs| KPI[KPI Retriever app/kpi_retriever.py]
    MCP -->|Retrieve Docs| DOC[Doc Retriever app/document_retriever.py]
    LLM_Report -->|Pre-retrieval| KPI
    LLM_Report -->|Pre-retrieval| DOC

    KPI -->|REST/pgSQL| DB[(Supabase Database)]
    DOC -->|REST/pgSQL & Vector Search| DB
    
    LLM_Chat -->|Synthesis Prompt| Groq[Groq Cloud API]
    LLM_Report -->|Synthesis Prompt| Groq
```

### Backend Components

1. **API Gateway / Router ([app/main.py](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/main.py))**
   * Acts as the main FastAPI entry point.
   * Exposes HTTP routes (`/chat`, `/chat/report`, `/chat/companies`) to the frontend.
   * Mounts the Model Context Protocol (MCP) server's Server-Sent Events (SSE) application under `/mcp`.
   * Serves static dashboard assets (`/static`).

2. **LLM Orchestration ([app/llm.py](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/llm.py))**
   * **Agentic Chat Loop (`generate_llm_answer`)**: Implements an interactive loop using Groq LLM. The LLM can dynamically call any of the defined MCP tools up to a limit of 3 rounds to retrieve data before synthesizing the final chat reply.
   * **ESG Report Pipeline (`generate_esg_report`)**: Orchestrates a pre-retrieval pipeline. It fetches primary company KPIs, peer benchmarks, policy narratives, and regulatory guidelines concurrently. It then formats and compresses this data into a single synthesis prompt to generate a 6-part ESG report in one LLM pass.

3. **Model Context Protocol Server ([app/mcp_server.py](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/mcp_server.py))**
   * Implements a **FastMCP** server containing 6 tools that can be invoked both by the agentic chat loop and externally by any MCP-compliant client:
     * `validate_user_query`: Analyzes company names and matches them to active database symbols.
     * `get_esg_kpis`: Queries relational metrics from Supabase.
     * `search_documents`: Performs vector search on ESG text disclosures.
     * `compare_peers`: Queries numerical metrics for multiple companies side-by-side.
     * `analyze_regulations`: Searches regulatory policies and guidelines.
     * `identify_policy_gaps`: Performs gap analysis between corporate policies and regulatory mandates.

4. **KPI Retrieval Engine ([app/kpi_retriever.py](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/kpi_retriever.py))**
   * Formulates queries to the Supabase REST API `kpi_metric_facts` table.
   * Resolves fuzzy metric names into structured SQL/Rest filters (e.g. mapping "Scope 1 emissions" to exact metric codes).
   * Implements custom pagination for company lookups to bypass PostgREST's 1,000-row query limit.

5. **Document Retrieval Engine ([app/document_retriever.py](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/document_retriever.py))**
   * Handles vector retrieval and search on company text chunks.
   * Fetches matching document chunks and their parent context to provide high-fidelity citations.

6. **Configuration Core ([app/config.py](file:///c:/Users/megha/Downloads/tatva-copilot-rag-backend/app/config.py))**
   * Configures environmental credentials, API keys, and workspace identifier defaults (e.g. `WORKSPACE_ID`).

---

## 3. Data Pipelines & Flow Control

### A. Agentic Chat Flow (`/chat`)
1. User submits a question along with configuration options (Primary Company, Peers, Year).
2. `generate_llm_answer` compiles a system instructions prompt and initializes the tool call loop.
3. The LLM decides which MCP tool to call (e.g. `get_esg_kpis` to find emissions data).
4. The tool executes, fetches data from Supabase, and returns the context.
5. The LLM decides whether it needs more information (up to 3 tools) or synthesizes the final reply containing bracketed citation markers (e.g. `[KPI1]`, `[S1]`).

### B. ESG Report Generation Flow (`/chat/report`)
1. User clicks **Generate ESG Report** in the dashboard.
2. The endpoint calls `generate_esg_report` which concurrently retrieves:
   * Structured KPIs for the primary company and selected peers.
   * 4 topic-based document search results (Governance, Emissions, Social/Wellness, Water/Waste).
   * Regulatory guideline documents.
3. Chunks are filtered, deduplicated, and truncated to a maximum of 800 characters to stay within **Groq's 12,000 Tokens per Minute (TPM)** limit.
4. The system issues a single request to Llama-3.3-70b-versatile, which returns a highly-structured markdown report containing citation badges mapped directly to the interactive sidebar inspector.

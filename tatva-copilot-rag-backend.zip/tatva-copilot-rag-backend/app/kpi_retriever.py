"""Exact KPI retrieval from Supabase with deterministic entity/metric matching."""

from __future__ import annotations

import math
import re
from typing import Any

from app.config import (
    SUPABASE_SERVICE_ROLE_KEY,
    SUPABASE_URL,
    WORKSPACE_ID,
    validate_database_config,
)


_supabase_client = None


SELECT_FIELDS = (
    "id, company_name, reporting_year, metric_category, metric_code, "
    "metric_label, scope, value, unit, previous_value, previous_unit, "
    "yoy_change_percent, evidence_text, source_page, "
    "raw_value, raw_unit, raw_previous_value, raw_previous_unit, "
    "normalized_value, normalized_unit, "
    "normalized_previous_value, normalized_previous_unit, "
    "normalization_note, kpi_review_status, kpi_review_note"
)


METRIC_LABELS = {
    "scope1_emissions": "Scope 1 emissions",
    "scope2_emissions": "Scope 2 emissions",
    "scope3_emissions": "Scope 3 emissions",
    "scope1_scope2_total_emissions": "Scope 1 and Scope 2 total emissions",
    "total_energy_consumption": "Total energy consumption",
    "renewable_energy_consumption": "Renewable energy consumption",
    "renewable_energy_percent": "Renewable energy percentage",
    "energy_intensity": "Energy intensity",
    "water_consumption": "Water consumption",
    "water_withdrawal": "Water withdrawal",
    "total_waste_generated": "Total waste generated",
    "waste_recycled": "Waste recycled",
    "waste_recycled_percent": "Waste recycled percentage",
    "female_employee_percent": "Female employee percentage",
    "women_on_board_percent": "Women on board percentage",
    "net_zero_target_year": "Net zero target year",
}


USABLE_REVIEW_STATUSES = {
    "evidence_verified",
    "derived_verified",
    "manual_correction",
    "auto_corrected",
    "verified_zero",
}


def get_supabase_client():
    global _supabase_client
    if _supabase_client is None:
        validate_database_config()
        try:
            from supabase import create_client
        except ImportError as exc:
            raise RuntimeError("Install the 'supabase' package before starting the API") from exc
        _supabase_client = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
    return _supabase_client


def normalize_company_key(company_name: str | None) -> str:
    value = str(company_name or "").lower().replace("&", " and ")
    value = re.sub(r"\b(private|public)\b", " ", value)
    value = re.sub(r"\b(limited|ltd|incorporated|inc|plc)\b", " ", value)
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def _company_match_score(company_input: str, candidate_name: str | None, nse_symbol: str | None = None) -> float:
    """Score a candidate company for tolerant but unambiguous retrieval.

    Users often type the common name ("Asian Paints") while the database stores
    the legal name ("Asian Paints Limited"). This scorer accepts exact normalized
    matches and unique prefix/token-subset matches, while still avoiding broad
    ambiguous guesses such as just "Tata".
    """
    term = re.sub(r"\s+", " ", str(company_input or "")).strip()
    candidate = re.sub(r"\s+", " ", str(candidate_name or "")).strip()
    if not term or not candidate:
        return 0.0

    term_lower = term.lower()
    candidate_lower = candidate.lower()
    symbol_lower = str(nse_symbol or "").strip().lower()
    if symbol_lower and symbol_lower == term_lower:
        return 1.10
    if candidate_lower == term_lower:
        return 1.05

    input_key = normalize_company_key(term)
    candidate_key = normalize_company_key(candidate)
    if not input_key or not candidate_key:
        return 0.0
    if candidate_key == input_key:
        return 1.00
    if candidate_key.startswith(input_key + " "):
        if len(input_key) >= 5 or len(input_key.split()) >= 2:
            return 0.94
        return 0.0
    if input_key.startswith(candidate_key + " "):
        return 0.88

    input_tokens = set(input_key.split())
    candidate_tokens = set(candidate_key.split())
    if not input_tokens or not candidate_tokens:
        return 0.0
    if input_tokens.issubset(candidate_tokens) and len(input_tokens) >= 2:
        return 0.90
    if input_key in candidate_key and len(input_key) >= 5:
        return 0.86
    return 0.0


def normalize_reporting_year(value: str | None) -> str | None:
    if not value:
        return None
    match = re.search(
        r"(?:fy\s*)?(20\d{2})\s*[-_/]\s*(?:20)?(\d{2})\b",
        str(value),
        flags=re.IGNORECASE,
    )
    if not match:
        return str(value).strip()
    start_year = int(match.group(1))
    end_year = int(match.group(2))
    if end_year != (start_year + 1) % 100:
        return str(value).strip()
    return f"FY {start_year}-{end_year:02d}"


def _append_metric(codes: list[str], metric_code: str) -> None:
    if metric_code not in codes:
        codes.append(metric_code)


def detect_metric_codes(query: str) -> list[str]:
    """Map user wording to metric codes without broad substring collisions."""
    q = re.sub(r"\s+", " ", query.lower()).strip()
    codes: list[str] = []

    total_scope_1_2 = bool(
        re.search(
            r"(?:total\s+)?scope\s*1\s*(?:\+|and|&)\s*scope\s*2\s+(?:total\s+)?emissions?",
            q,
        )
        or re.search(r"scope\s*1\s*\+\s*2\s+(?:total\s+)?emissions?", q)
    )
    if total_scope_1_2 and "compare" not in q and "versus" not in q and not re.search(r"\bvs\b", q):
        _append_metric(codes, "scope1_scope2_total_emissions")

    explicit_scopes: list[str] = []
    for number in (1, 2, 3):
        if re.search(rf"\bscope\s*[- ]?{number}\b", q):
            explicit_scopes.append(f"scope{number}_emissions")
    if re.search(r"\bscope\s*1\s*[,/]\s*2\s*(?:,|and|&)\s*3\b", q):
        explicit_scopes = ["scope1_emissions", "scope2_emissions", "scope3_emissions"]

    if explicit_scopes and not (total_scope_1_2 and len(explicit_scopes) == 2 and len(codes) == 1):
        for code in explicit_scopes:
            _append_metric(codes, code)
    elif not explicit_scopes and re.search(r"\b(ghg|carbon)\s+(?:footprint|emissions?)\b|\bemissions?\b", q):
        for code in ("scope1_emissions", "scope2_emissions", "scope3_emissions"):
            _append_metric(codes, code)

    renewable = bool(re.search(r"\brenewable\s+energy\b", q))
    if renewable:
        if re.search(r"\b(percent(?:age)?|share|mix|ratio)\b", q):
            _append_metric(codes, "renewable_energy_percent")
        elif re.search(r"\b(consumption|consumed|use|used|amount|gj|mwh)\b", q):
            _append_metric(codes, "renewable_energy_consumption")
        else:
            _append_metric(codes, "renewable_energy_consumption")
            _append_metric(codes, "renewable_energy_percent")
    elif re.search(r"\benergy\s+intensity\b", q):
        _append_metric(codes, "energy_intensity")
    elif re.search(r"\b(total\s+)?energy(?:\s+(?:consumption|consumed|use|used))?\b", q):
        _append_metric(codes, "total_energy_consumption")

    has_withdrawal = bool(re.search(r"\bwater\s+withdraw(?:al|n)?\b", q))
    has_consumption = bool(re.search(r"\bwater\s+consum(?:ption|ed)\b", q))
    if has_withdrawal:
        _append_metric(codes, "water_withdrawal")
    if has_consumption:
        _append_metric(codes, "water_consumption")
    if re.search(r"\bwater\b", q) and not (has_withdrawal or has_consumption):
        _append_metric(codes, "water_consumption")
        _append_metric(codes, "water_withdrawal")

    recycled_waste = bool(re.search(r"\b(?:waste\s+recycl|recycled\s+waste|recycling)\w*\b", q))
    if recycled_waste:
        if re.search(r"\b(percent(?:age)?|rate|ratio|share)\b", q):
            _append_metric(codes, "waste_recycled_percent")
        else:
            _append_metric(codes, "waste_recycled")
    if re.search(r"\btotal\s+waste(?:\s+generated)?\b|\bwaste\s+generated\b", q):
        _append_metric(codes, "total_waste_generated")
    elif re.search(r"\bwaste\b", q) and not recycled_waste:
        _append_metric(codes, "total_waste_generated")
        _append_metric(codes, "waste_recycled")
        _append_metric(codes, "waste_recycled_percent")

    if re.search(r"\b(?:female|women|gender)\s+(?:employees?|workforce|diversity|ratios?)\b|\bfemale\s+workforce\b|\bgender\s+diversity\b", q):
        _append_metric(codes, "female_employee_percent")
    if re.search(r"\bwom[ae]n\s+(?:on|in)\s+(?:the\s+)?board\b|\bboard\s+diversity\b", q):
        _append_metric(codes, "women_on_board_percent")
    if re.search(r"\bnet[- ]?zero(?:\s+target)?\b", q):
        _append_metric(codes, "net_zero_target_year")

    return codes


def is_all_kpi_query(query: str) -> bool:
    q = query.lower()
    return bool(
        re.search(r"\b(all|every|overview|summary)\b.*\b(kpis?|metrics?)\b", q)
        or re.search(r"\b(kpis?|metrics?)\b.*\b(all|overview|summary)\b", q)
        or re.search(r"\bshow\s+(?:me\s+)?(?:the\s+)?kpis?\b", q)
        or re.search(r"\b(compare|benchmark)\b.*\b(?:esg\s+)?kpis?\b", q)
        or re.fullmatch(r"\s*(?:esg\s+)?kpis?\s*", q)
    )


def _execute_company_query(client, workspace_id: str, field: str, value: str):
    return (
        client.table("companies")
        .select("company_name, nse_symbol, company_name_normalized")
        .eq("workspace_id", workspace_id)
        .ilike(field, value)
        .limit(20)
        .execute()
    ).data or []


def _execute_fact_company_query(client, workspace_id: str, value: str):
    return (
        client.table("kpi_metric_facts")
        .select("company_name")
        .eq("workspace_id", workspace_id)
        .ilike("company_name", value)
        .limit(100)
        .execute()
    ).data or []


def resolve_company_name(
    company_input: str,
    client=None,
    workspace_id: str | None = None,
) -> str | None:
    """Resolve only an unambiguous legal name or NSE symbol; never guess."""
    term = re.sub(r"\s+", " ", str(company_input or "")).strip().strip("\"'")
    if not term:
        return None
    client = client or get_supabase_client()
    workspace_id = workspace_id or WORKSPACE_ID

    candidates: dict[str, dict] = {}

    def collect(rows):
        for row in rows:
            name = row.get("company_name")
            if name:
                candidates[name.lower()] = row

    # Exact/legal-name variants first.
    for pattern in (
        term,
        f"{term} Limited",
        f"{term} Ltd",
        f"{term} Private Limited",
    ):
        collect(_execute_company_query(client, workspace_id, "company_name", pattern))
    collect(_execute_company_query(client, workspace_id, "nse_symbol", term))

    # Then common-name prefix/contains matches from both companies and facts.
    # The facts fallback is important when kpi_metric_facts has a cleaned legal
    # name but the companies table was created earlier with a slightly different
    # variant.
    for pattern in (f"{term}%", f"%{term}%"):
        collect(_execute_company_query(client, workspace_id, "company_name", pattern))
        collect(_execute_fact_company_query(client, workspace_id, pattern))

    input_key = normalize_company_key(term)
    exact_key_matches = [
        row for row in candidates.values()
        if normalize_company_key(row.get("company_name")) == input_key
        or str(row.get("nse_symbol") or "").lower() == term.lower()
    ]
    unique_exact = sorted({row["company_name"] for row in exact_key_matches})
    if len(unique_exact) == 1:
        return unique_exact[0]
    if len(unique_exact) > 1:
        return None

    collect(_execute_company_query(client, workspace_id, "company_name", f"{term}%"))
    key_matches = sorted({
        row["company_name"]
        for row in candidates.values()
        if normalize_company_key(row.get("company_name")) == input_key
    })
    if len(key_matches) == 1:
        return key_matches[0]

    prefix_matches = sorted({
        row["company_name"]
        for row in candidates.values()
        if normalize_company_key(row.get("company_name")).startswith(input_key)
    })
    if len(prefix_matches) == 1:
        return prefix_matches[0]

    scored = sorted(
        (
            (_company_match_score(term, row.get("company_name"), row.get("nse_symbol")), row["company_name"])
            for row in candidates.values()
            if row.get("company_name")
        ),
        reverse=True,
    )
    scored = [(score, name) for score, name in scored if score >= 0.86]
    if not scored:
        return None
    top_score = scored[0][0]
    top_names = sorted({name for score, name in scored if abs(score - top_score) < 0.001})
    return top_names[0] if len(top_names) == 1 else None


def _year_sort_value(value: str | None) -> int:
    normalized = normalize_reporting_year(value)
    match = re.search(r"20\d{2}", normalized or "")
    return int(match.group()) if match else -1


def _row_has_value(row: dict) -> bool:
    return row.get("normalized_value") is not None or row.get("value") is not None


def select_usable_rows(
    rows: list[dict],
    reporting_year: str | None = None,
) -> list[dict]:
    requested_year = normalize_reporting_year(reporting_year)
    usable = [
        row for row in rows
        if row.get("kpi_review_status") in USABLE_REVIEW_STATUSES and _row_has_value(row)
    ]
    if requested_year:
        usable = [
            row for row in usable
            if normalize_reporting_year(row.get("reporting_year")) == requested_year
        ]

    # One row per company/metric. If no year was requested, use the latest year.
    selected: dict[tuple[str, str], dict] = {}
    quality_rank = {
        "derived_verified": 6,
        "manual_correction": 5,
        "evidence_verified": 4,
        "auto_corrected": 3,
        "verified_zero": 2,
        None: 1,
    }
    for row in usable:
        key = (str(row.get("company_name")), str(row.get("metric_code")))
        current = selected.get(key)
        candidate_rank = (
            _year_sort_value(row.get("reporting_year")),
            quality_rank.get(row.get("kpi_review_status"), 0),
            bool(row.get("evidence_text")),
        )
        current_rank = (
            _year_sort_value(current.get("reporting_year")),
            quality_rank.get(current.get("kpi_review_status"), 0),
            bool(current.get("evidence_text")),
        ) if current else (-2, -1, False)
        if candidate_rank > current_rank:
            selected[key] = row
    return list(selected.values())


def _retrieve_company_rows(
    company_name: str,
    metric_codes: list[str],
    reporting_year: str | None,
    client,
    workspace_id: str,
) -> list[dict]:
    # Company records can preserve the casing from the first time a company was
    # inserted (for example "DEEP INDUSTRIES LIMITED"), while KPI facts may use
    # cleaned title-case names ("Deep Industries Limited"). Use an exact
    # case-insensitive match for the fact lookup so resolution is not defeated by
    # harmless casing differences.
    request = (
        client.table("kpi_metric_facts")
        .select(SELECT_FIELDS)
        .eq("workspace_id", workspace_id)
        .ilike("company_name", company_name)
    )
    if metric_codes:
        request = request.in_("metric_code", metric_codes)
    rows = request.execute().data or []
    if not rows:
        request = (
            client.table("kpi_metric_facts")
            .select(SELECT_FIELDS)
            .eq("workspace_id", workspace_id)
            .ilike("company_name", f"{company_name}%")
        )
        if metric_codes:
            request = request.in_("metric_code", metric_codes)
        rows = request.execute().data or []
    selected = select_usable_rows(rows, reporting_year=reporting_year)
    order = {code: index for index, code in enumerate(metric_codes)}
    return sorted(
        selected,
        key=lambda row: (
            order.get(row.get("metric_code"), len(order)),
            str(row.get("metric_category") or ""),
            str(row.get("metric_code") or ""),
        ),
    )


def _sort_company_rows(rows: list[dict], metric_codes: list[str]) -> list[dict]:
    order = {code: index for index, code in enumerate(metric_codes)}
    return sorted(
        rows,
        key=lambda row: (
            order.get(row.get("metric_code"), len(order)),
            str(row.get("metric_category") or ""),
            str(row.get("metric_code") or ""),
        ),
    )


def _retrieve_company_rows_fuzzy(
    company_input: str,
    metric_codes: list[str],
    reporting_year: str | None,
    client,
    workspace_id: str,
) -> list[dict]:
    """Retrieve facts by common/partial company name when canonical resolution fails."""
    term = re.sub(r"\s+", " ", str(company_input or "")).strip().strip("\"'")
    if not term:
        return []

    rows_by_id: dict[str, dict] = {}

    def collect(pattern: str) -> None:
        request = (
            client.table("kpi_metric_facts")
            .select(SELECT_FIELDS)
            .eq("workspace_id", workspace_id)
            .ilike("company_name", pattern)
            .limit(1000)
        )
        if metric_codes:
            request = request.in_("metric_code", metric_codes)
        for row in request.execute().data or []:
            row_id = str(row.get("id") or f"{row.get('company_name')}::{row.get('metric_code')}::{row.get('reporting_year')}")
            rows_by_id[row_id] = row

    for pattern in (
        term,
        f"{term} Limited",
        f"{term} Ltd",
        f"{term}%",
        f"%{term}%",
    ):
        collect(pattern)

    if not rows_by_id:
        return []

    company_scores: list[tuple[float, str]] = []
    for name in sorted({str(row.get("company_name") or "") for row in rows_by_id.values() if row.get("company_name")}):
        score = _company_match_score(term, name)
        if score >= 0.86:
            company_scores.append((score, name))
    if not company_scores:
        return []

    company_scores.sort(reverse=True)
    top_score = company_scores[0][0]
    top_names = sorted({name for score, name in company_scores if abs(score - top_score) < 0.001})
    if len(top_names) != 1:
        return []

    selected_company = top_names[0]
    selected_rows = [
        row
        for row in rows_by_id.values()
        if normalize_company_key(row.get("company_name")) == normalize_company_key(selected_company)
    ]
    selected = select_usable_rows(selected_rows, reporting_year=reporting_year)
    return _sort_company_rows(selected, metric_codes)


def retrieve_kpis(
    company_name: str,
    query: str,
    reporting_year: str | None = None,
    client=None,
    workspace_id: str | None = None,
) -> list[dict]:
    metric_codes = detect_metric_codes(query)
    if not metric_codes and not is_all_kpi_query(query):
        return []
    client = client or get_supabase_client()
    workspace_id = workspace_id or WORKSPACE_ID
    resolved = resolve_company_name(company_name, client=client, workspace_id=workspace_id)
    if not resolved:
        return _retrieve_company_rows_fuzzy(
            company_name,
            metric_codes,
            reporting_year,
            client,
            workspace_id,
        )
    rows = _retrieve_company_rows(
        resolved,
        metric_codes,
        reporting_year,
        client,
        workspace_id,
    )
    if rows:
        return rows
    return _retrieve_company_rows_fuzzy(
        company_name,
        metric_codes,
        reporting_year,
        client,
        workspace_id,
    )


def retrieve_kpis_for_companies(
    company_names: list[str],
    query: str,
    reporting_year: str | None = None,
    client=None,
    workspace_id: str | None = None,
) -> list[dict]:
    metric_codes = detect_metric_codes(query)
    if not metric_codes and not is_all_kpi_query(query):
        return []
    client = client or get_supabase_client()
    workspace_id = workspace_id or WORKSPACE_ID
    rows: list[dict] = []
    resolved_names: set[str] = set()
    for company_name in company_names:
        resolved = resolve_company_name(company_name, client=client, workspace_id=workspace_id)
        company_rows: list[dict] = []
        if resolved and resolved.lower() not in resolved_names:
            company_rows = _retrieve_company_rows(
                resolved,
                metric_codes,
                reporting_year,
                client,
                workspace_id,
            )
        if not company_rows:
            company_rows = _retrieve_company_rows_fuzzy(
                company_name,
                metric_codes,
                reporting_year,
                client,
                workspace_id,
            )
        if not company_rows:
            continue
        actual_name = str(company_rows[0].get("company_name") or resolved or company_name).lower()
        if actual_name in resolved_names:
            continue
        resolved_names.add(actual_name)
        rows.extend(company_rows)
    return rows


def format_number(value: Any) -> str:
    if value is None:
        return "Not available"
    try:
        number = float(value)
        if not math.isfinite(number):
            return "Not available"
        if number.is_integer():
            return f"{int(number):,}"
        if abs(number) < 0.01 and number != 0:
            return f"{number:.6g}"
        return f"{number:,.2f}"
    except (TypeError, ValueError):
        return str(value)


def format_value_with_unit(value: Any, unit: str | None) -> str:
    if value is None:
        return "Not available"
    formatted = format_number(value)
    clean_unit = str(unit or "").strip()
    if not clean_unit:
        return formatted
    if clean_unit == "%":
        return f"{formatted}%"
    return f"{formatted} {clean_unit}"


def format_yoy_text(yoy_value: Any) -> str | None:
    try:
        yoy = float(yoy_value)
    except (TypeError, ValueError):
        return None
    if yoy > 0:
        return f"reduced by {abs(yoy):.2f}%"
    if yoy < 0:
        return f"increased by {abs(yoy):.2f}%"
    return "no YoY change"


def get_display_value_and_unit(row: dict) -> tuple[Any, str]:
    value = row.get("normalized_value")
    unit = row.get("normalized_unit")
    if value is None:
        value = row.get("value")
        unit = row.get("unit")
    return value, unit or ""


def get_display_previous_value_and_unit(row: dict) -> tuple[Any, str]:
    value = row.get("normalized_previous_value")
    unit = row.get("normalized_previous_unit")
    if value is None:
        value = row.get("previous_value")
        unit = row.get("previous_unit") or row.get("unit")
    return value, unit or ""


def get_raw_value_and_unit(row: dict) -> tuple[Any, str]:
    value = row.get("raw_value")
    unit = row.get("raw_unit")
    if value is None:
        value = row.get("value")
        unit = row.get("unit")
    return value, unit or ""


def _citation_for_row(row: dict, source_id: str) -> dict | None:
    evidence = row.get("evidence_text")
    if not evidence:
        return None
    return {
        "source_id": source_id,
        "type": "kpi_evidence",
        "company_name": row.get("company_name"),
        "reporting_year": row.get("reporting_year"),
        "metric_code": row.get("metric_code"),
        "metric_label": row.get("metric_label"),
        "source_page": row.get("source_page"),
        "evidence_text": re.sub(r"\s+", " ", str(evidence)).strip()[:500],
    }


def _confidence_for_rows(rows: list[dict], expected_count: int) -> str:
    if not rows:
        return "low"
    complete = len(rows) >= expected_count if expected_count else True
    all_evidenced = all(row.get("evidence_text") for row in rows)
    all_verified = all(row.get("kpi_review_status") in USABLE_REVIEW_STATUSES for row in rows)
    return "high" if complete and all_evidenced and all_verified else "medium"


def format_kpi_answer(company_name: str, query: str, rows: list[dict]) -> dict:
    expected_codes = detect_metric_codes(query)
    if not rows:
        metric_text = ", ".join(METRIC_LABELS.get(code, code) for code in expected_codes)
        detail = f" for {metric_text}" if metric_text else ""
        return {
            "answer": (
                f"I could not find a verified KPI value{detail} for an unambiguous match to "
                f"'{company_name}'."
            ),
            "kpi_facts": [],
            "citations": [],
            "confidence": "low",
        }

    resolved_company = rows[0].get("company_name") or company_name
    lines = [f"Verified KPI values for {resolved_company}:"]
    citations: list[dict] = []

    for index, row in enumerate(rows, start=1):
        label = row.get("metric_label") or METRIC_LABELS.get(row.get("metric_code"), row.get("metric_code"))
        year = normalize_reporting_year(row.get("reporting_year")) or "year not available"
        value, unit = get_display_value_and_unit(row)
        previous, previous_unit = get_display_previous_value_and_unit(row)
        line = f"- {label} ({year}): {format_value_with_unit(value, unit)}"
        if previous is not None:
            line += f"; previous: {format_value_with_unit(previous, previous_unit)}"
        yoy_text = format_yoy_text(row.get("yoy_change_percent"))
        if yoy_text:
            line += f"; YoY: {yoy_text}"

        citation = _citation_for_row(row, f"KPI{index}")
        if citation:
            line += f" [{citation['source_id']}]"
            citations.append(citation)
        lines.append(line)

    return {
        "answer": "\n".join(lines),
        "kpi_facts": rows,
        "citations": citations,
        "confidence": _confidence_for_rows(rows, len(expected_codes)),
    }


def format_comparison_answer(company_names: list[str], query: str, rows: list[dict]) -> dict:
    expected_codes = detect_metric_codes(query)
    metric_codes = (
        expected_codes
        or (list(METRIC_LABELS) if is_all_kpi_query(query) else [])
        or list(dict.fromkeys(row.get("metric_code") for row in rows))
    )
    if not metric_codes:
        return {
            "answer": "I could not identify a supported KPI metric in the comparison request.",
            "kpi_facts": [],
            "citations": [],
            "confidence": "low",
            "warnings": [],
        }

    rows_by_key = {
        (normalize_company_key(row.get("company_name")), row.get("metric_code")): row
        for row in rows
    }
    canonical_company_names = {
        normalize_company_key(row.get("company_name")): row.get("company_name")
        for row in rows
        if row.get("company_name")
    }
    requested_companies = list(dict.fromkeys(company_names))
    display_companies = [
        canonical_company_names.get(normalize_company_key(company), company)
        for company in requested_companies
    ]
    is_two_company_comparison = len(requested_companies) == 2

    lines = ["KPI comparison based on verified structured data:", ""]
    if is_two_company_comparison:
        lines.append(f"| Metric | {display_companies[0]} | {display_companies[1]} |")
        lines.append("|---|---:|---:|")
    else:
        lines.append("| Metric | Company | Year | Current Value | Previous Value | YoY |")
        lines.append("|---|---|---|---:|---:|---|")
    citations: list[dict] = []
    found_count = 0
    warnings: list[str] = []

    incompatible_metrics: set[str] = set()
    for metric_code in metric_codes:
        units = {
            get_display_value_and_unit(row)[1]
            for row in rows
            if row.get("metric_code") == metric_code and get_display_value_and_unit(row)[0] is not None
        }
        units.discard("")
        if len(units) > 1:
            incompatible_metrics.add(metric_code)
            warnings.append(
                f"{METRIC_LABELS.get(metric_code, metric_code)} uses incompatible units across companies: "
                f"{', '.join(sorted(units))}. Values are shown but must not be ranked or ratio-compared."
            )

    for metric_code in metric_codes:
        label = METRIC_LABELS.get(metric_code, metric_code)
        pivot_cells: list[str] = []
        for requested_company in requested_companies:
            company_key = normalize_company_key(requested_company)
            row = rows_by_key.get((company_key, metric_code))
            display_company = canonical_company_names.get(company_key, requested_company)
            if row is None:
                if is_two_company_comparison:
                    pivot_cells.append("Not available")
                else:
                    lines.append(
                        f"| {label} | {display_company} | Not available | Not available | Not available | Not available |"
                    )
                continue

            found_count += 1
            value, unit = get_display_value_and_unit(row)
            previous, previous_unit = get_display_previous_value_and_unit(row)
            yoy = format_yoy_text(row.get("yoy_change_percent")) or "Not available"
            source_id = f"KPI{len(citations) + 1}"
            citation = _citation_for_row(row, source_id)
            marker = ""
            if citation:
                citations.append(citation)
                marker = f" [{source_id}]"
            if is_two_company_comparison:
                details = [normalize_reporting_year(row.get("reporting_year")) or "Year not available"]
                if previous is not None:
                    details.append(f"Prev: {format_value_with_unit(previous, previous_unit)}")
                if yoy != "Not available":
                    details.append(f"YoY: {yoy}")
                pivot_cells.append(
                    f"{format_value_with_unit(value, unit)}{marker}<br>"
                    + " · ".join(details)
                )
            else:
                lines.append(
                    f"| {label} | {row.get('company_name')} | "
                    f"{normalize_reporting_year(row.get('reporting_year')) or 'Not available'} | "
                    f"{format_value_with_unit(value, unit)}{marker} | "
                    f"{format_value_with_unit(previous, previous_unit)} | {yoy} |"
                )
        if is_two_company_comparison:
            lines.append(f"| {label} | {pivot_cells[0]} | {pivot_cells[1]} |")

    if warnings:
        lines.extend(["", "Comparison warnings:"])
        lines.extend(f"- {warning}" for warning in warnings)

    total_expected = len(metric_codes) * len(requested_companies)
    all_verified = all(row.get("kpi_review_status") in USABLE_REVIEW_STATUSES for row in rows)
    confidence = "low" if found_count == 0 else (
        "high"
        if (
            found_count == total_expected
            and len(citations) == found_count
            and not incompatible_metrics
            and all_verified
        )
        else "medium"
    )
    return {
        "answer": "\n".join(lines),
        "kpi_facts": rows,
        "citations": citations,
        "confidence": confidence,
        "warnings": warnings,
    }

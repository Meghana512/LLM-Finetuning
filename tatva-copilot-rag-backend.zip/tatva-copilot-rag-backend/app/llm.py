import os
import logging
from typing import Any
import json
import re

logger = logging.getLogger(__name__)

REGULATORY_PATTERN = re.compile(
    r"\b(brsr|ifrs\s*s[12]|gri|sasb|tcfd|csrd|sebi|regulat(?:ion|ory)|"
    r"framework|reporting requirement|disclosure requirement|principle\s*\d+)\b",
    flags=re.IGNORECASE,
)

def is_regulatory_query(message: str) -> bool:
    return bool(REGULATORY_PATTERN.search(message or ""))

def generate_llm_answer(
    query: str,
    *,
    company_name: str | None = None,
    reporting_year: str | None = None,
    peer_companies: list[str] = None,
    fallback_answer: str = ""
) -> dict[str, Any]:
    """Generate a synthesized, structured answer using Groq Llama 3.1 8B with MCP Tools."""
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        logger.warning("GROQ_API_KEY is not configured. Falling back to direct retrieval answer.")
        return {
            "intent": "company_qa",
            "answer": fallback_answer,
            "kpi_facts": [],
            "citations": [],
            "retrieved_chunks": [],
            "confidence": "low",
            "warnings": ["GROQ_API_KEY not configured"]
        }

    try:
        from groq import Groq
    except ImportError:
        logger.warning("The 'groq' package is not installed. Falling back to direct retrieval answer.")
        return {
            "intent": "company_qa",
            "answer": fallback_answer,
            "kpi_facts": [],
            "citations": [],
            "retrieved_chunks": [],
            "confidence": "low",
            "warnings": ["Groq SDK not installed"]
        }

    model_name = os.getenv("LLM_MODEL", "llama-3.1-8b-instant")
    client = Groq(api_key=api_key)

    # 1. Define tools schemas for Groq
    tools = [
        {
            "type": "function",
            "function": {
                "name": "search_esg_kpis",
                "description": (
                    "Retrieve verified numerical ESG KPI metrics (emissions, employee ratios, "
                    "water usage, board diversity, etc.) and YoY changes. "
                    "Supports single-company or multi-company comparison."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "company_names": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of company names to search. E.g. ['Siemens Limited']."
                        },
                        "query": {
                            "type": "string",
                            "description": "The specific ESG metric query. E.g. 'emissions', 'water'."
                        },
                        "reporting_year": {
                            "type": "string",
                            "description": "Optional reporting year filter. E.g. 'FY 2022-23'."
                        }
                    },
                    "required": ["company_names", "query"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "search_esg_documents",
                "description": (
                    "Search unstructured ESG PDF documents and annual reports of a company. "
                    "Use this when the query asks 'why', 'how', 'explain', or seeks policy details."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The textual query. E.g. 'safety policies', 'water reduction methods'."
                        },
                        "company_name": {
                            "type": "string",
                            "description": "The primary company name (optional)."
                        },
                        "reporting_year": {
                            "type": "string",
                            "description": "Optional reporting year filter. E.g. 'FY 2022-23'."
                        },
                        "peer_companies": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Optional list of peer companies to search alongside primary company."
                        }
                    },
                    "required": ["query"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "retrieve_regulations",
                "description": (
                    "Retrieve official regulatory ESG guidance, frameworks, guidelines, and disclosure requirements (e.g. BRSR principles, GRI guidelines)."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The specific regulatory topic or question. E.g. 'Scope 3 reporting guidelines'."
                        },
                        "framework": {
                            "type": "string",
                            "description": "Optional ESG framework name. E.g. 'BRSR', 'GRI'. Defaults to 'BRSR'."
                        }
                    },
                    "required": ["query"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "retrieve_benchmarks",
                "description": (
                    "Retrieve industry best-practice disclosures and peer ESG benchmarks from disclosures."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The ESG topic to benchmark. E.g. 'carbon neutrality target best practices'."
                        },
                        "peer_companies": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Optional list of specific peer companies to fetch benchmarking data for."
                        }
                    },
                    "required": ["query"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "analyze_gaps",
                "description": (
                    "Compare disclosures of a primary company against peer disclosures on a specific ESG topic to identify reporting gaps."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "primary_company": {
                            "type": "string",
                            "description": "The name of the target company. E.g. 'Siemens Limited'."
                        },
                        "peer_companies": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of peer company names to compare against."
                        },
                        "topic": {
                            "type": "string",
                            "description": "The specific ESG topic or metric to assess. E.g. 'Scope 3 purchased goods', 'water management policy'."
                        }
                    },
                    "required": ["primary_company", "peer_companies", "topic"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "draft_disclosure",
                "description": (
                    "Generate a structured draft for an ESG disclosure section (e.g. climate governance, board oversight) using retrieved guidelines and KPIs."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "company_name": {
                            "type": "string",
                            "description": "The company name."
                        },
                        "topic": {
                            "type": "string",
                            "description": "The disclosure section topic. E.g. 'Board oversight on ESG'."
                        },
                        "retrieved_context": {
                            "type": "string",
                            "description": "The framework guidelines, requirements, or peer templates to align with."
                        },
                        "kpis": {
                            "type": "object",
                            "description": "Optional key-value dictionary of metrics to compile or mention in the draft."
                        }
                    },
                    "required": ["company_name", "topic", "retrieved_context"]
                }
            }
        }
    ]

    # Prepare message thread
    system_prompt = (
        "You are an expert ESG (Environmental, Social, and Governance) analysis assistant.\n\n"
        "Your task is to answer the user's query using the tools provided. Follow these guidelines:\n\n"
        "1. TOOL CALLING & COMPANY OVERRIDES:\n"
        "   - Carefully read the user's query. If the query explicitly mentions specific company names (e.g. 'Wipro', 'Tata Steel', 'TCS', 'Siemens', 'Infosys'), you MUST extract those companies and search for them using the tools.\n"
        "   - In this case, you MUST ignore the 'Context Company' and 'Context Peers' provided in the prompt, as they are just fallback settings from the user's sidebar. Only use 'Context Company' and 'Context Peers' if the user's query does not name any specific companies (e.g. 'What is our water policy?').\n"
        "   - Use `search_esg_kpis` for numerical metrics, percentages, YoY values, or comparative numbers.\n"
        "   - Use `search_esg_documents` for policies, descriptions, strategies, or explanations of a company.\n"
        "   - Use `retrieve_regulations` for official regulatory guidelines or framework rules (like BRSR principles, GRI requirements).\n"
        "   - Use `retrieve_benchmarks` to fetch industry best practices or peer disclosures for comparative benchmarking.\n"
        "   - Use `analyze_gaps` when the user explicitly requests to compare disclosures and detect gaps (e.g. comparing Wipro vs ITC on Scope 3).\n"
        "   - Use `draft_disclosure` to write drafts of ESG disclosures using policy details, governance data, and KPIs.\n"
        "   - You can call multiple tools sequentially or concurrently in the same turn if the query requires them.\n\n"
        "2. ANSWER SYNTHESIS (Once tools return data):\n"
        "   - Present all values, numbers, and policies returned by the tools in a detailed, professional, and clear narrative.\n"
        "   - If the KPI tool returns values, print the exact numbers, units, reporting years, and YoY change percentages.\n"
        "   - When presenting comparisons or gaps, use a structured Markdown table or clear bulleted lists.\n"
        "   - Maintain and include the exact citation markers (e.g. [KPI1], [KPI2], [S1], [S2], [B1], [B2]) immediately following any fact, metric, or statement that references that source.\n"
        "   - Keep your response strictly factual. Do not make up any values, names, or years.\n"
        "   - If the tools return no relevant data or indicate that values are not available, clearly state that the information was not found."
    )

    peers = peer_companies or []
    user_prompt = (
        f"Query: {query}\n"
        f"Context Company: {company_name}\n"
        f"Context Reporting Year: {reporting_year}\n"
        f"Context Peers: {peers}"
    )

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}
    ]

    # Accumulators for API response metadata
    captured_data = {
        "kpi_facts": [],
        "citations": [],
        "retrieved_chunks": [],
        "confidence": "low",
        "warnings": [],
        "tools_called": []
    }

    # Execute tool calling loop
    # Groq supports up to 3 turns
    for turn in range(3):
        # DEBUG PRINT: Print the messages sent to Groq
        logger.info(f"--- TURN {turn} MESSAGES ---")
        for i, msg in enumerate(messages):
            role = msg.get("role")
            tc = msg.get("tool_calls")
            tc_id = msg.get("tool_call_id")
            content_snippet = str(msg.get("content", ""))[:120].replace('\n', ' ')
            logger.info(f" Message {i} | Role: {role} | ToolCallId: {tc_id} | HasToolCalls: {bool(tc)} | Content: {content_snippet}...")

        try:
            response = client.chat.completions.create(
                model=model_name,
                messages=messages,
                tools=tools,
                tool_choice="auto",
                temperature=0.0,
            )
        except Exception as exc:
            logger.error(f"Error calling Groq API: {exc}")
            break

        message = response.choices[0].message
        
        # DEBUG PRINT: Print Groq's response
        logger.info(f"--- TURN {turn} RESPONSE ---")
        logger.info(f" Response Role: {message.role}")
        logger.info(f" Response Content: {message.content}")
        logger.info(f" Response ToolCalls: {message.tool_calls}")

        # Explicitly serialize the assistant message object into a clean dictionary
        msg_dict = {
            "role": "assistant"
        }
        if message.content is not None:
            msg_dict["content"] = message.content
        if message.tool_calls:
            msg_dict["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments
                    }
                }
                for tc in message.tool_calls
            ]
        
        messages.append(msg_dict)

        if not message.tool_calls:
            # Final response received
            break

        # Process tool calls requested by LLM
        for tool_call in message.tool_calls:
            tool_name = tool_call.function.name
            tool_args = json.loads(tool_call.function.arguments)
            
            captured_data["tools_called"].append(tool_name)
            logger.info(f"LLM requested tool call: {tool_name} with args {tool_args}")

            tool_output_dict = {}
            try:
                if tool_name == "search_esg_kpis":
                    from app.mcp_server import search_esg_kpis
                    tool_output_dict = search_esg_kpis(**tool_args)
                    
                    if tool_output_dict.get("kpi_facts"):
                        captured_data["kpi_facts"].extend(tool_output_dict["kpi_facts"])
                    if tool_output_dict.get("citations"):
                        captured_data["citations"].extend(tool_output_dict["citations"])
                    if tool_output_dict.get("warnings"):
                        captured_data["warnings"].extend(tool_output_dict["warnings"])
                    
                    # Update confidence
                    tc = tool_output_dict.get("confidence", "low")
                    if tc == "high":
                        captured_data["confidence"] = "high"
                    elif tc == "medium" and captured_data["confidence"] != "high":
                        captured_data["confidence"] = "medium"

                elif tool_name == "search_esg_documents":
                    from app.mcp_server import search_esg_documents
                    tool_output_dict = search_esg_documents(**tool_args)
                    
                    if tool_output_dict.get("citations"):
                        captured_data["citations"].extend(tool_output_dict["citations"])
                    if tool_output_dict.get("retrieved_chunks"):
                        captured_data["retrieved_chunks"].extend(tool_output_dict["retrieved_chunks"])
                    if tool_output_dict.get("warnings"):
                        captured_data["warnings"].extend(tool_output_dict["warnings"])
                    
                    # Update confidence
                    tc = tool_output_dict.get("confidence", "low")
                    if tc == "high":
                        captured_data["confidence"] = "high"
                    elif tc == "medium" and captured_data["confidence"] != "high":
                        captured_data["confidence"] = "medium"

                elif tool_name == "retrieve_regulations":
                    from app.mcp_server import retrieve_regulations
                    tool_output_dict = retrieve_regulations(**tool_args)
                    
                    if tool_output_dict.get("citations"):
                        captured_data["citations"].extend(tool_output_dict["citations"])
                    if tool_output_dict.get("retrieved_chunks"):
                        captured_data["retrieved_chunks"].extend(tool_output_dict["retrieved_chunks"])
                    if tool_output_dict.get("warnings"):
                        captured_data["warnings"].extend(tool_output_dict["warnings"])

                elif tool_name == "retrieve_benchmarks":
                    from app.mcp_server import retrieve_benchmarks
                    tool_output_dict = retrieve_benchmarks(**tool_args)
                    
                    if tool_output_dict.get("citations"):
                        captured_data["citations"].extend(tool_output_dict["citations"])
                    if tool_output_dict.get("retrieved_chunks"):
                        captured_data["retrieved_chunks"].extend(tool_output_dict["retrieved_chunks"])
                    if tool_output_dict.get("warnings"):
                        captured_data["warnings"].extend(tool_output_dict["warnings"])

                elif tool_name == "analyze_gaps":
                    from app.mcp_server import analyze_gaps
                    tool_output_dict = analyze_gaps(**tool_args)
                    
                    if tool_output_dict.get("citations"):
                        captured_data["citations"].extend(tool_output_dict["citations"])
                    if tool_output_dict.get("retrieved_chunks"):
                        captured_data["retrieved_chunks"].extend(tool_output_dict["retrieved_chunks"])
                    if tool_output_dict.get("warnings"):
                        captured_data["warnings"].extend(tool_output_dict["warnings"])
                    
                    tool_output_dict["answer"] = tool_output_dict.get("comparison_data", "")

                elif tool_name == "draft_disclosure":
                    from app.mcp_server import draft_disclosure
                    tool_output_dict = draft_disclosure(**tool_args)
                    
                    tool_output_dict["answer"] = tool_output_dict.get("draft_prompt_context", "")

                else:
                    tool_output_dict = {"answer": f"Error: Tool {tool_name} not recognized."}
            except Exception as e:
                logger.error(f"Error executing tool {tool_name}: {e}", exc_info=True)
                tool_output_dict = {"answer": f"Error executing tool: {str(e)}"}

            # Send back the clean text 'answer' field to the LLM context
            tool_content = tool_output_dict.get("answer", "")
            messages.append({
                "role": "tool",
                "tool_call_id": tool_call.id,
                "name": tool_name,
                "content": tool_content
            })

    final_answer = (messages[-1].get("content") or "").strip() if messages else ""
    if not final_answer:
        final_answer = fallback_answer

    # Deduplicate citations, kpi_facts, and retrieved_chunks
    unique_citations = []
    seen_citation_ids = set()
    for citation in captured_data["citations"]:
        c_id = citation.get("source_id")
        if c_id not in seen_citation_ids:
            seen_citation_ids.add(c_id)
            unique_citations.append(citation)

    unique_facts = []
    seen_fact_ids = set()
    for fact in captured_data["kpi_facts"]:
        f_id = fact.get("id") or f"{fact.get('company_name')}::{fact.get('metric_code')}::{fact.get('reporting_year')}"
        if f_id not in seen_fact_ids:
            seen_fact_ids.add(f_id)
            unique_facts.append(fact)

    unique_chunks = []
    seen_chunk_ids = set()
    for chunk in captured_data["retrieved_chunks"]:
        ch_id = chunk.get("source_id")
        if ch_id not in seen_chunk_ids:
            seen_chunk_ids.add(ch_id)
            unique_chunks.append(chunk)

    # Determine intent
    tools_called = captured_data["tools_called"]
    has_multiple_companies = len(peers) > 0 or len(seen_fact_ids) > 1
    
    if "analyze_gaps" in tools_called or ("search_esg_kpis" in tools_called and has_multiple_companies):
        intent = "peer_benchmarking"
    elif "draft_disclosure" in tools_called:
        intent = "disclosure_generation"
    elif ("retrieve_regulations" in tools_called or "search_esg_documents" in tools_called) and is_regulatory_query(query):
        intent = "regulatory_qa"
    else:
        intent = "company_qa"

    return {
        "intent": intent,
        "answer": final_answer,
        "kpi_facts": unique_facts,
        "citations": unique_citations,
        "retrieved_chunks": unique_chunks,
        "confidence": captured_data["confidence"],
        "warnings": sorted(list(set(captured_data["warnings"]))),
        "tools_called": tools_called,
    }


def generate_esg_report(
    *,
    company_name: str,
    reporting_year: str | None = None,
    peer_companies: list[str] = None,
) -> dict[str, Any]:
    """Pre-retrieves KPIs, policies, regulations, and peer benchmarks to generate a detailed ESG report in one LLM call."""
    from app.kpi_retriever import retrieve_kpis, retrieve_kpis_for_companies, format_value_with_unit, format_yoy_text
    from app.document_retriever import retrieve_document_chunks

    peers = [p for p in (peer_companies or []) if p]

    # 1. Retrieve KPI facts
    kpis_primary = retrieve_kpis(company_name, "all KPIs", reporting_year)
    kpis_peers = []
    if peers:
        kpis_peers = retrieve_kpis_for_companies(peers, "all KPIs", reporting_year)

    # 2. Retrieve document chunks
    topics = [
        "climate governance and board oversight risk management",
        "greenhouse gas emissions reduction energy efficiency goals",
        "occupational health and safety employee training gender diversity",
        "waste generation recycling water consumption conservation"
    ]

    chunks_primary = []
    for q in topics:
        res = retrieve_document_chunks(q, company=company_name, reporting_year=reporting_year, final_limit=2)
        chunks_primary.extend(res.get("chunks") or [])

    chunks_peers = []
    if peers:
        for peer in peers:
            res = retrieve_document_chunks(
                "emissions energy employee wellness training waste water policies",
                company=peer,
                reporting_year=reporting_year,
                final_limit=2
            )
            chunks_peers.extend(res.get("chunks") or [])

    # Regulatory chunks
    res_reg = retrieve_document_chunks(
        "BRSR framework guidelines disclosure requirements principle 3 and principle 6 emissions energy waste water safety",
        company=None,
        corpus_type="regulatory",
        final_limit=2
    )
    chunks_regulatory = res_reg.get("chunks") or []

    # 3. Map & deduplicate KPI facts and Document chunks
    citations = []
    kpi_facts_out = []
    unique_facts_seen = set()

    # Process primary company KPIs
    primary_kpi_lines = []
    kpi_index = 1
    for row in kpis_primary:
        key = (row.get("company_name"), row.get("metric_code"), row.get("reporting_year"))
        if key in unique_facts_seen:
            continue
        unique_facts_seen.add(key)

        source_id = f"KPI{kpi_index}"
        kpi_index += 1

        evidence = row.get("evidence_text")
        citation = {
            "source_id": source_id,
            "type": "kpi_evidence",
            "company_name": row.get("company_name"),
            "reporting_year": row.get("reporting_year"),
            "metric_code": row.get("metric_code"),
            "metric_label": row.get("metric_label"),
            "source_page": row.get("source_page"),
            "evidence_text": re.sub(r"\s+", " ", str(evidence)).strip()[:500] if evidence else "",
        }
        citations.append(citation)
        kpi_facts_out.append(row)

        val = row.get("normalized_value") if row.get("normalized_value") is not None else row.get("value")
        unit = row.get("normalized_unit") if row.get("normalized_unit") is not None else row.get("unit") or ""
        prev_val = row.get("normalized_previous_value") if row.get("normalized_previous_value") is not None else row.get("previous_value")
        prev_unit = row.get("normalized_previous_unit") if row.get("normalized_previous_unit") is not None else row.get("previous_unit") or unit or ""

        val_str = format_value_with_unit(val, unit)
        prev_str = format_value_with_unit(prev_val, prev_unit) if prev_val is not None else "N/A"
        yoy_str = format_yoy_text(row.get("yoy_change_percent")) or "N/A"

        label = row.get("metric_label") or row.get("metric_code")
        year = row.get("reporting_year") or "N/A"
        primary_kpi_lines.append(
            f"- {label} ({year}): {val_str} (previous: {prev_str}, YoY: {yoy_str}) [{source_id}]"
        )

    # Process peer company KPIs
    peer_kpi_lines = []
    for row in kpis_peers:
        key = (row.get("company_name"), row.get("metric_code"), row.get("reporting_year"))
        if key in unique_facts_seen:
            continue
        unique_facts_seen.add(key)

        source_id = f"KPI{kpi_index}"
        kpi_index += 1

        evidence = row.get("evidence_text")
        citation = {
            "source_id": source_id,
            "type": "kpi_evidence",
            "company_name": row.get("company_name"),
            "reporting_year": row.get("reporting_year"),
            "metric_code": row.get("metric_code"),
            "metric_label": row.get("metric_label"),
            "source_page": row.get("source_page"),
            "evidence_text": re.sub(r"\s+", " ", str(evidence)).strip()[:500] if evidence else "",
        }
        citations.append(citation)
        kpi_facts_out.append(row)

        val = row.get("normalized_value") if row.get("normalized_value") is not None else row.get("value")
        unit = row.get("normalized_unit") if row.get("normalized_unit") is not None else row.get("unit") or ""
        prev_val = row.get("normalized_previous_value") if row.get("normalized_previous_value") is not None else row.get("previous_value")
        prev_unit = row.get("normalized_previous_unit") if row.get("normalized_previous_unit") is not None else row.get("previous_unit") or unit or ""

        val_str = format_value_with_unit(val, unit)
        prev_str = format_value_with_unit(prev_val, prev_unit) if prev_val is not None else "N/A"
        yoy_str = format_yoy_text(row.get("yoy_change_percent")) or "N/A"

        comp = row.get("company_name") or "Peer"
        label = row.get("metric_label") or row.get("metric_code")
        year = row.get("reporting_year") or "N/A"
        peer_kpi_lines.append(
            f"- [{comp}] {label} ({year}): {val_str} (previous: {prev_str}, YoY: {yoy_str}) [{source_id}]"
        )

    # Process document chunks
    retrieved_chunks_out = []
    seen_chunk_ids = set()

    # Process primary document chunks
    primary_doc_lines = []
    doc_index = 1
    for chunk in chunks_primary:
        cid = chunk.get("id")
        if not cid or cid in seen_chunk_ids:
            continue
        seen_chunk_ids.add(cid)

        source_id = f"S{doc_index}"
        doc_index += 1

        text = (chunk.get("chunk_text") or chunk.get("context_text") or "").strip()
        if len(text) > 800:
            text = text[:797] + "..."
        quote = text[:300] + "..." if len(text) > 300 else text

        citations.append({
            "source_id": source_id,
            "source_chunk_id": cid,
            "document_id": chunk.get("document_id"),
            "company": chunk.get("company"),
            "document": chunk.get("report_type") or chunk.get("document_id") or "BRSR Report",
            "page": chunk.get("page_number"),
            "section": chunk.get("section_title"),
            "quote": quote,
        })

        retrieved_chunks_out.append({
            "source_id": source_id,
            "chunk_id": cid,
            "parent_chunk_id": chunk.get("parent_context_chunk_id") or chunk.get("parent_chunk_id"),
            "document_id": chunk.get("document_id"),
            "company": chunk.get("company"),
            "reporting_year": chunk.get("reporting_year"),
            "page": chunk.get("page_number"),
            "section": chunk.get("section_title"),
            "text": text,
            "score": chunk.get("rerank_score"),
            "retrieval_sources": chunk.get("retrieval_sources", []),
        })

        sec = chunk.get("section_title") or "General"
        pg = chunk.get("page_number")
        primary_doc_lines.append(
            f"[{source_id}] (Section: {sec}, Page: {pg}): {text.strip()}"
        )

    # Process peer document chunks
    peer_doc_lines = []
    for chunk in chunks_peers:
        cid = chunk.get("id")
        if not cid or cid in seen_chunk_ids:
            continue
        seen_chunk_ids.add(cid)

        source_id = f"S_peer{doc_index}"
        doc_index += 1

        text = (chunk.get("chunk_text") or chunk.get("context_text") or "").strip()
        if len(text) > 800:
            text = text[:797] + "..."
        quote = text[:300] + "..." if len(text) > 300 else text

        citations.append({
            "source_id": source_id,
            "source_chunk_id": cid,
            "document_id": chunk.get("document_id"),
            "company": chunk.get("company"),
            "document": chunk.get("report_type") or chunk.get("document_id") or "BRSR Report",
            "page": chunk.get("page_number"),
            "section": chunk.get("section_title"),
            "quote": quote,
        })

        retrieved_chunks_out.append({
            "source_id": source_id,
            "chunk_id": cid,
            "parent_chunk_id": chunk.get("parent_context_chunk_id") or chunk.get("parent_chunk_id"),
            "document_id": chunk.get("document_id"),
            "company": chunk.get("company"),
            "reporting_year": chunk.get("reporting_year"),
            "page": chunk.get("page_number"),
            "section": chunk.get("section_title"),
            "text": text,
            "score": chunk.get("rerank_score"),
            "retrieval_sources": chunk.get("retrieval_sources", []),
        })

        comp = chunk.get("company") or "Peer"
        sec = chunk.get("section_title") or "General"
        pg = chunk.get("page_number")
        peer_doc_lines.append(
            f"[{source_id}] (Company: {comp}, Section: {sec}, Page: {pg}): {text.strip()}"
        )

    # Process regulatory chunks
    reg_doc_lines = []
    for chunk in chunks_regulatory:
        cid = chunk.get("id")
        if not cid or cid in seen_chunk_ids:
            continue
        seen_chunk_ids.add(cid)

        source_id = f"S_reg{doc_index}"
        doc_index += 1

        text = (chunk.get("chunk_text") or chunk.get("context_text") or "").strip()
        if len(text) > 800:
            text = text[:797] + "..."
        quote = text[:300] + "..." if len(text) > 300 else text

        citations.append({
            "source_id": source_id,
            "source_chunk_id": cid,
            "document_id": chunk.get("document_id"),
            "company": chunk.get("company"),
            "document": chunk.get("report_type") or chunk.get("document_id") or "Regulatory Guideline",
            "page": chunk.get("page_number"),
            "section": chunk.get("section_title"),
            "quote": quote,
        })

        retrieved_chunks_out.append({
            "source_id": source_id,
            "chunk_id": cid,
            "parent_chunk_id": chunk.get("parent_context_chunk_id") or chunk.get("parent_chunk_id"),
            "document_id": chunk.get("document_id"),
            "company": chunk.get("company"),
            "reporting_year": chunk.get("reporting_year"),
            "page": chunk.get("page_number"),
            "section": chunk.get("section_title"),
            "text": text,
            "score": chunk.get("rerank_score"),
            "retrieval_sources": chunk.get("retrieval_sources", []),
        })

        sec = chunk.get("section_title") or "General"
        pg = chunk.get("page_number")
        reg_doc_lines.append(
            f"[{source_id}] (Section: {sec}, Page: {pg}): {text.strip()}"
        )

    # 4. Generate report via Groq
    system_prompt = (
        "You are an expert ESG (Environmental, Social, and Governance) report writer.\n\n"
        "Your task is to generate a comprehensive, professional, and detailed ESG Report for the company based on the pre-retrieved context data provided.\n\n"
        "Your report MUST contain the following sections:\n"
        "1. Executive Summary: High-level overview of the company's ESG standing.\n"
        "2. Environmental Performance: Detail emissions, energy usage, waste, water, and peer comparisons. Cite exact values, units, and YoY change percent.\n"
        "3. Social and Employee Welfare: Discuss safety, diversity, training, and employee metrics.\n"
        "4. Governance & Board Oversight: Detail governance structure, board committees, and risk management.\n"
        "5. Peer Benchmarking & Gap Analysis: Compare the company's performance against its peers (if provided).\n"
        "6. Regulatory Compliance: Assess alignment with BRSR requirements.\n\n"
        "CRITICAL CITATION INSTRUCTIONS:\n"
        "- Every numerical fact, policy statement, or benchmark comparison MUST be directly followed by its corresponding citation marker (e.g., [KPI1], [KPI2], [S1], [S2], [S_peer1], [S_reg1], etc.) from the source context.\n"
        "- Only use citation markers that are explicitly present in the context. Never invent citation markers.\n"
        "- Format the report beautifully using clean Markdown (headers, bullet points, and tables where appropriate)."
    )

    primary_kpi_str = '\n'.join(primary_kpi_lines) if primary_kpi_lines else 'No KPI facts found.'
    primary_doc_str = '\n\n'.join(primary_doc_lines) if primary_doc_lines else 'No policy document extracts found.'

    user_prompt = (
        f"Generate an ESG Report for {company_name} for reporting year {reporting_year or 'all years'}.\n\n"
        f"--- CONTEXT DATA ---\n\n"
        f"### Primary Company: {company_name}\n"
        f"#### Verified numerical KPIs:\n"
        f"{primary_kpi_str}\n\n"
        f"#### Core Policy & Document Extracts:\n"
        f"{primary_doc_str}\n\n"
    )
    if peers:
        peer_kpi_str = '\n'.join(peer_kpi_lines) if peer_kpi_lines else 'No peer KPIs found.'
        peer_doc_str = '\n\n'.join(peer_doc_lines) if peer_doc_lines else 'No peer policy extracts found.'
        user_prompt += (
            f"### Peer Companies: {', '.join(peers)}\n"
            f"#### Peer numerical KPIs:\n"
            f"{peer_kpi_str}\n\n"
            f"#### Peer Policy & Document Extracts:\n"
            f"{peer_doc_str}\n\n"
        )
    reg_doc_str = '\n\n'.join(reg_doc_lines) if reg_doc_lines else 'No regulatory framework data found.'
    user_prompt += (
        f"### Regulatory BRSR Framework Guidance:\n"
        f"{reg_doc_str}\n"
    )

    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        logger.warning("GROQ_API_KEY is not configured for report generation.")
        return {
            "intent": "peer_benchmarking" if peers else "company_qa",
            "answer": "Error: GROQ_API_KEY is not configured.",
            "kpi_facts": kpi_facts_out,
            "citations": citations,
            "retrieved_chunks": retrieved_chunks_out,
            "confidence": "low",
            "warnings": ["GROQ_API_KEY not configured"],
            "tools_called": []
        }

    try:
        from groq import Groq
    except ImportError:
        logger.warning("The 'groq' package is not installed.")
        return {
            "intent": "peer_benchmarking" if peers else "company_qa",
            "answer": "Error: The 'groq' package is not installed.",
            "kpi_facts": kpi_facts_out,
            "citations": citations,
            "retrieved_chunks": retrieved_chunks_out,
            "confidence": "low",
            "warnings": ["Groq SDK not installed"],
            "tools_called": []
        }

    model_name = os.getenv("LLM_MODEL", "llama-3.1-8b-instant")
    client = Groq(api_key=api_key)

    try:
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.1,
        )
        final_answer = response.choices[0].message.content
    except Exception as exc:
        logger.error(f"Error calling Groq API for report generation: {exc}")
        final_answer = f"Error generating report via Groq: {exc}"

    return {
        "intent": "peer_benchmarking" if peers else "company_qa",
        "answer": final_answer,
        "kpi_facts": kpi_facts_out,
        "citations": citations,
        "retrieved_chunks": retrieved_chunks_out,
        "confidence": "high" if len(citations) > 5 else "medium",
        "warnings": [],
        "tools_called": []
    }

